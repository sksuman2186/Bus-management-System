<?php

	$currDir=dirname(__FILE__);
	include("$currDir/defaultLang.php");
	include("$currDir/language.php");
	include("$currDir/lib.php");
	@include("$currDir/hooks/availability.php");
	include("$currDir/availability_dml.php");

	$perm=getTablePermissions('availability');
	if(!$perm[0]){
		echo error_message($Translation['tableAccessDenied'], false);
		echo '<script>setTimeout("window.location=\'index.php?signOut=1\'", 2000);</script>';
		exit;
	}

	$x = new DataList;
	$x->TableName = "availability";


	$x->QueryFieldsTV = array(   
		"`availability`.`id`" => "id",
		"IF(    CHAR_LENGTH(`buses1`.`number`), CONCAT_WS('',   `buses1`.`number`), '') /* Bus */" => "bus",
		"IF(    CHAR_LENGTH(`routes1`.`name`) || CHAR_LENGTH(`routes1`.`time`), CONCAT_WS('',   `routes1`.`name`, '  :', `routes1`.`time`), '') /* Route */" => "route",
		"IF(    CHAR_LENGTH(`routes1`.`amount`), CONCAT_WS('',   `routes1`.`amount`), '') /* Amount */" => "amount",
		"if(`availability`.`date`,date_format(`availability`.`date`,'%m/%d/%Y'),'')" => "date",
		"TIME_FORMAT(`availability`.`time`, '%r')" => "time",
		"`availability`.`status`" => "status"
	);

	$x->SortFields = array(   
		1 => '`availability`.`id`',
		2 => '`buses1`.`number`',
		3 => 3,
		4 => '`routes1`.`amount`',
		5 => '`availability`.`date`',
		6 => '`availability`.`time`',
		7 => 7
	);

	$x->QueryFieldsCSV = array(   
		"`availability`.`id`" => "id",
		"IF(    CHAR_LENGTH(`buses1`.`number`), CONCAT_WS('',   `buses1`.`number`), '') /* Bus */" => "bus",
		"IF(    CHAR_LENGTH(`routes1`.`name`) || CHAR_LENGTH(`routes1`.`time`), CONCAT_WS('',   `routes1`.`name`, '  :', `routes1`.`time`), '') /* Route */" => "route",
		"IF(    CHAR_LENGTH(`routes1`.`amount`), CONCAT_WS('',   `routes1`.`amount`), '') /* Amount */" => "amount",
		"if(`availability`.`date`,date_format(`availability`.`date`,'%m/%d/%Y'),'')" => "date",
		"TIME_FORMAT(`availability`.`time`, '%r')" => "time",
		"`availability`.`status`" => "status"
	);

	$x->QueryFieldsFilters = array(   
		"`availability`.`id`" => "ID",
		"IF(    CHAR_LENGTH(`buses1`.`number`), CONCAT_WS('',   `buses1`.`number`), '') /* Bus */" => "Bus",
		"IF(    CHAR_LENGTH(`routes1`.`name`) || CHAR_LENGTH(`routes1`.`time`), CONCAT_WS('',   `routes1`.`name`, '  :', `routes1`.`time`), '') /* Route */" => "Route",
		"IF(    CHAR_LENGTH(`routes1`.`amount`), CONCAT_WS('',   `routes1`.`amount`), '') /* Amount */" => "Amount",
		"`availability`.`date`" => "Date",
		"`availability`.`time`" => "Departure Time",
		"`availability`.`status`" => "Status"
	);


	$x->QueryFieldsQS = array(   
		"`availability`.`id`" => "id",
		"IF(    CHAR_LENGTH(`buses1`.`number`), CONCAT_WS('',   `buses1`.`number`), '') /* Bus */" => "bus",
		"IF(    CHAR_LENGTH(`routes1`.`name`) || CHAR_LENGTH(`routes1`.`time`), CONCAT_WS('',   `routes1`.`name`, '  :', `routes1`.`time`), '') /* Route */" => "route",
		"IF(    CHAR_LENGTH(`routes1`.`amount`), CONCAT_WS('',   `routes1`.`amount`), '') /* Amount */" => "amount",
		"if(`availability`.`date`,date_format(`availability`.`date`,'%m/%d/%Y'),'')" => "date",
		"TIME_FORMAT(`availability`.`time`, '%r')" => "time",
		"`availability`.`status`" => "status"
	);


	$x->filterers = array(  'bus' => 'Bus', 'route' => 'Route');

	$x->QueryFrom = "`availability` LEFT JOIN `buses` as buses1 ON `buses1`.`id`=`availability`.`bus` LEFT JOIN `routes` as routes1 ON `routes1`.`id`=`availability`.`route` ";
	$x->QueryWhere = '';
	$x->QueryOrder = '';

	$x->AllowSelection = 1;
	$x->HideTableView = ($perm[2]==0 ? 1 : 0);
	$x->AllowDelete = $perm[4];
	$x->AllowMassDelete = true;
	$x->AllowInsert = $perm[1];
	$x->AllowUpdate = $perm[3];
	$x->SeparateDV = 1;
	$x->AllowDeleteOfParents = 0;
	$x->AllowFilters = 1;
	$x->AllowSavingFilters = 1;
	$x->AllowSorting = 1;
	$x->AllowNavigation = 1;
	$x->AllowPrinting = 1;
	$x->AllowCSV = 1;
	$x->RecordsPerPage = 10;
	$x->QuickSearch = 1;
	$x->QuickSearchText = $Translation["quick search"];
	$x->ScriptFileName = "availability_view.php";
	$x->RedirectAfterInsert = "availability_view.php?SelectedID=#ID#";
	$x->TableTitle = "Availability";
	$x->TableIcon = "resources/table_icons/accept.png";
	$x->PrimaryKey = "`availability`.`id`";
	$x->DefaultSortField = '1';
	$x->DefaultSortDirection = 'desc';

	$x->ColWidth   = array(  150, 150, 150, 150, 150, 150);
	$x->ColCaption = array("Bus", "Route", "Amount", "Date", "Departure Time", "Status");
	$x->ColFieldName = array('bus', 'route', 'amount', 'date', 'time', 'status');
	$x->ColNumber  = array(2, 3, 4, 5, 6, 7);


	$x->Template = 'templates/availability_templateTV.html';
	$x->SelectedTemplate = 'templates/availability_templateTVS.html';
	$x->TemplateDV = 'templates/availability_templateDV.html';
	$x->TemplateDVP = 'templates/availability_templateDVP.html';

	$x->ShowTableHeader = 1;
	$x->TVClasses = "";
	$x->DVClasses = "";
	$x->HighlightColor = '#FFF0C2';


	$DisplayRecords = $_REQUEST['DisplayRecords'];
	if(!in_array($DisplayRecords, array('user', 'group'))){ $DisplayRecords = 'all'; }
	if($perm[2]==1 || ($perm[2]>1 && $DisplayRecords=='user' && !$_REQUEST['NoFilter_x'])){ // view owner only
		$x->QueryFrom.=', membership_userrecords';
		$x->QueryWhere="where `availability`.`id`=membership_userrecords.pkValue and membership_userrecords.tableName='availability' and lcase(membership_userrecords.memberID)='".getLoggedMemberID()."'";
	}elseif($perm[2]==2 || ($perm[2]>2 && $DisplayRecords=='group' && !$_REQUEST['NoFilter_x'])){ // view group only
		$x->QueryFrom.=', membership_userrecords';
		$x->QueryWhere="where `availability`.`id`=membership_userrecords.pkValue and membership_userrecords.tableName='availability' and membership_userrecords.groupID='".getLoggedGroupID()."'";
	}elseif($perm[2]==3){ 
	
	}elseif($perm[2]==0){ 
		$x->QueryFields = array("Not enough permissions" => "NEP");
		$x->QueryFrom = '`availability`';
		$x->QueryWhere = '';
		$x->DefaultSortField = '';
	}

	$render=TRUE;
	if(function_exists('availability_init')){
		$args=array();
		$render=availability_init($x, getMemberInfo(), $args);
	}

	if($render) $x->Render();


	$headerCode='';
	if(function_exists('availability_header')){
		$args=array();
		$headerCode=availability_header($x->ContentType, getMemberInfo(), $args);
	}  
	if(!$headerCode){
		include_once("$currDir/header.php"); 
	}else{
		ob_start(); include_once("$currDir/header.php"); $dHeader=ob_get_contents(); ob_end_clean();
		echo str_replace('<%%HEADER%%>', $dHeader, $headerCode);
	}

	echo $x->HTML;
	$footerCode='';
	if(function_exists('availability_footer')){
		$args=array();
		$footerCode=availability_footer($x->ContentType, getMemberInfo(), $args);
	}  
	if(!$footerCode){
		include_once("$currDir/footer.php"); 
	}else{
		ob_start(); include_once("$currDir/footer.php"); $dFooter=ob_get_contents(); ob_end_clean();
		echo str_replace('<%%FOOTER%%>', $dFooter, $footerCode);
	}
?>
