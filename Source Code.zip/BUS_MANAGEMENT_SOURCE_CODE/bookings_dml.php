<?php


function bookings_insert(){
	global $Translation;


	$arrPerm=getTablePermissions('bookings');
	if(!$arrPerm[1]){
		return false;
	}

	$data['id_number'] = makeSafe($_REQUEST['id_number']);
		if($data['id_number'] == empty_lookup_value){ $data['id_number'] = ''; }
	$data['fullname'] = makeSafe($_REQUEST['id_number']);
		if($data['fullname'] == empty_lookup_value){ $data['fullname'] = ''; }
	$data['phone'] = makeSafe($_REQUEST['id_number']);
		if($data['phone'] == empty_lookup_value){ $data['phone'] = ''; }
	$data['bus'] = makeSafe($_REQUEST['bus']);
		if($data['bus'] == empty_lookup_value){ $data['bus'] = ''; }
	$data['seat'] = makeSafe($_REQUEST['seat']);
		if($data['seat'] == empty_lookup_value){ $data['seat'] = ''; }
	$data['amount'] = makeSafe($_REQUEST['bus']);
		if($data['amount'] == empty_lookup_value){ $data['amount'] = ''; }
	$data['date'] = makeSafe($_REQUEST['bus']);
		if($data['date'] == empty_lookup_value){ $data['date'] = ''; }
	$data['time'] = makeSafe($_REQUEST['bus']);
		if($data['time'] == empty_lookup_value){ $data['time'] = ''; }
	$data['luggage'] = makeSafe($_REQUEST['luggage']);
		if($data['luggage'] == empty_lookup_value){ $data['luggage'] = ''; }
	$data['date_booked'] = parseCode('<%%creationDate%%>', true, true);
	if($data['date'] == '') $data['date'] = "1";


	if(function_exists('bookings_before_insert')){
		$args=array();
		if(!bookings_before_insert($data, getMemberInfo(), $args)){ return false; }
	}

	$o = array('silentErrors' => true);
	sql('insert into `bookings` set       `id_number`=' . (($data['id_number'] !== '' && $data['id_number'] !== NULL) ? "'{$data['id_number']}'" : 'NULL') . ', `fullname`=' . (($data['fullname'] !== '' && $data['fullname'] !== NULL) ? "'{$data['fullname']}'" : 'NULL') . ', `phone`=' . (($data['phone'] !== '' && $data['phone'] !== NULL) ? "'{$data['phone']}'" : 'NULL') . ', `bus`=' . (($data['bus'] !== '' && $data['bus'] !== NULL) ? "'{$data['bus']}'" : 'NULL') . ', `seat`=' . (($data['seat'] !== '' && $data['seat'] !== NULL) ? "'{$data['seat']}'" : 'NULL') . ', `amount`=' . (($data['amount'] !== '' && $data['amount'] !== NULL) ? "'{$data['amount']}'" : 'NULL') . ', `date`=' . (($data['date'] !== '' && $data['date'] !== NULL) ? "'{$data['date']}'" : 'NULL') . ', `time`=' . (($data['time'] !== '' && $data['time'] !== NULL) ? "'{$data['time']}'" : 'NULL') . ', `luggage`=' . (($data['luggage'] !== '' && $data['luggage'] !== NULL) ? "'{$data['luggage']}'" : 'NULL') . ', `date_booked`=' . "'{$data['date_booked']}'", $o);
	if($o['error']!=''){
		echo $o['error'];
		echo "<a href=\"bookings_view.php?addNew_x=1\">{$Translation['< back']}</a>";
		exit;
	}

	$recID = db_insert_id(db_link());


	if(function_exists('bookings_after_insert')){
		$res = sql("select * from `bookings` where `id`='" . makeSafe($recID, false) . "' limit 1", $eo);
		if($row = db_fetch_assoc($res)){
			$data = array_map('makeSafe', $row);
		}
		$data['selectedID'] = makeSafe($recID, false);
		$args=array();
		if(!bookings_after_insert($data, getMemberInfo(), $args)){ return $recID; }
	}


	set_record_owner('bookings', $recID, getLoggedMemberID());

	return $recID;
}

function bookings_delete($selected_id, $AllowDeleteOfParents=false, $skipChecks=false){

	global $Translation;
	$selected_id=makeSafe($selected_id);


	$arrPerm=getTablePermissions('bookings');
	$ownerGroupID=sqlValue("select groupID from membership_userrecords where tableName='bookings' and pkValue='$selected_id'");
	$ownerMemberID=sqlValue("select lcase(memberID) from membership_userrecords where tableName='bookings' and pkValue='$selected_id'");
	if(($arrPerm[4]==1 && $ownerMemberID==getLoggedMemberID()) || ($arrPerm[4]==2 && $ownerGroupID==getLoggedGroupID()) || $arrPerm[4]==3){

	}else{
		return $Translation['You don\'t have enough permissions to delete this record'];
	}


	if(function_exists('bookings_before_delete')){
		$args=array();
		if(!bookings_before_delete($selected_id, $skipChecks, getMemberInfo(), $args))
			return $Translation['Couldn\'t delete this record'];
	}

	sql("delete from `bookings` where `id`='$selected_id'", $eo);


	if(function_exists('bookings_after_delete')){
		$args=array();
		bookings_after_delete($selected_id, getMemberInfo(), $args);
	}


	sql("delete from membership_userrecords where tableName='bookings' and pkValue='$selected_id'", $eo);
}

function bookings_update($selected_id){
	global $Translation;


	$arrPerm=getTablePermissions('bookings');
	$ownerGroupID=sqlValue("select groupID from membership_userrecords where tableName='bookings' and pkValue='".makeSafe($selected_id)."'");
	$ownerMemberID=sqlValue("select lcase(memberID) from membership_userrecords where tableName='bookings' and pkValue='".makeSafe($selected_id)."'");
	if(($arrPerm[3]==1 && $ownerMemberID==getLoggedMemberID()) || ($arrPerm[3]==2 && $ownerGroupID==getLoggedGroupID()) || $arrPerm[3]==3){ 

	}else{
		return false;
	}

	$data['id_number'] = makeSafe($_REQUEST['id_number']);
		if($data['id_number'] == empty_lookup_value){ $data['id_number'] = ''; }
	$data['fullname'] = makeSafe($_REQUEST['id_number']);
		if($data['fullname'] == empty_lookup_value){ $data['fullname'] = ''; }
	$data['phone'] = makeSafe($_REQUEST['id_number']);
		if($data['phone'] == empty_lookup_value){ $data['phone'] = ''; }
	$data['bus'] = makeSafe($_REQUEST['bus']);
		if($data['bus'] == empty_lookup_value){ $data['bus'] = ''; }
	$data['seat'] = makeSafe($_REQUEST['seat']);
		if($data['seat'] == empty_lookup_value){ $data['seat'] = ''; }
	$data['amount'] = makeSafe($_REQUEST['bus']);
		if($data['amount'] == empty_lookup_value){ $data['amount'] = ''; }
	$data['date'] = makeSafe($_REQUEST['bus']);
		if($data['date'] == empty_lookup_value){ $data['date'] = ''; }
	$data['time'] = makeSafe($_REQUEST['bus']);
		if($data['time'] == empty_lookup_value){ $data['time'] = ''; }
	$data['luggage'] = makeSafe($_REQUEST['luggage']);
		if($data['luggage'] == empty_lookup_value){ $data['luggage'] = ''; }
	$data['date_booked'] = parseMySQLDate('', '<%%creationDate%%>');
	$data['selectedID']=makeSafe($selected_id);


	if(function_exists('bookings_before_update')){
		$args=array();
		if(!bookings_before_update($data, getMemberInfo(), $args)){ return false; }
	}

	$o=array('silentErrors' => true);
	sql('update `bookings` set       `id_number`=' . (($data['id_number'] !== '' && $data['id_number'] !== NULL) ? "'{$data['id_number']}'" : 'NULL') . ', `fullname`=' . (($data['fullname'] !== '' && $data['fullname'] !== NULL) ? "'{$data['fullname']}'" : 'NULL') . ', `phone`=' . (($data['phone'] !== '' && $data['phone'] !== NULL) ? "'{$data['phone']}'" : 'NULL') . ', `bus`=' . (($data['bus'] !== '' && $data['bus'] !== NULL) ? "'{$data['bus']}'" : 'NULL') . ', `seat`=' . (($data['seat'] !== '' && $data['seat'] !== NULL) ? "'{$data['seat']}'" : 'NULL') . ', `amount`=' . (($data['amount'] !== '' && $data['amount'] !== NULL) ? "'{$data['amount']}'" : 'NULL') . ', `date`=' . (($data['date'] !== '' && $data['date'] !== NULL) ? "'{$data['date']}'" : 'NULL') . ', `time`=' . (($data['time'] !== '' && $data['time'] !== NULL) ? "'{$data['time']}'" : 'NULL') . ', `luggage`=' . (($data['luggage'] !== '' && $data['luggage'] !== NULL) ? "'{$data['luggage']}'" : 'NULL') . ', `date_booked`=`date_booked`' . " where `id`='".makeSafe($selected_id)."'", $o);
	if($o['error']!=''){
		echo $o['error'];
		echo '<a href="bookings_view.php?SelectedID='.urlencode($selected_id)."\">{$Translation['< back']}</a>";
		exit;
	}



	if(function_exists('bookings_after_update')){
		$res = sql("SELECT * FROM `bookings` WHERE `id`='{$data['selectedID']}' LIMIT 1", $eo);
		if($row = db_fetch_assoc($res)){
			$data = array_map('makeSafe', $row);
		}
		$data['selectedID'] = $data['id'];
		$args = array();
		if(!bookings_after_update($data, getMemberInfo(), $args)){ return; }
	}


	sql("update membership_userrecords set dateUpdated='".time()."' where tableName='bookings' and pkValue='".makeSafe($selected_id)."'", $eo);

}

function bookings_form($selected_id = '', $AllowUpdate = 1, $AllowInsert = 1, $AllowDelete = 1, $ShowCancel = 0, $TemplateDV = '', $TemplateDVP = ''){
	
	global $Translation;


	$arrPerm=getTablePermissions('bookings');
	if(!$arrPerm[1] && $selected_id==''){ return ''; }
	$AllowInsert = ($arrPerm[1] ? true : false);

	$dvprint = false;
	if($selected_id && $_REQUEST['dvprint_x'] != ''){
		$dvprint = true;
	}

	$filterer_id_number = thisOr(undo_magic_quotes($_REQUEST['filterer_id_number']), '');
	$filterer_bus = thisOr(undo_magic_quotes($_REQUEST['filterer_bus']), '');
	$filterer_seat = thisOr(undo_magic_quotes($_REQUEST['filterer_seat']), '');




	$rnd1 = ($dvprint ? rand(1000000, 9999999) : '');

	$combo_id_number = new DataCombo;

	$combo_bus = new DataCombo;

	$combo_seat = new DataCombo;

	$combo_date_booked = new DateCombo;
	$combo_date_booked->DateFormat = "mdy";
	$combo_date_booked->MinYear = 1900;
	$combo_date_booked->MaxYear = 2100;
	$combo_date_booked->DefaultDate = parseMySQLDate('<%%creationDate%%>', '<%%creationDate%%>');
	$combo_date_booked->MonthNames = $Translation['month names'];
	$combo_date_booked->NamePrefix = 'date_booked';

	if($selected_id){

		if(!$arrPerm[2]){
			return "";
		}

		$ownerGroupID=sqlValue("select groupID from membership_userrecords where tableName='bookings' and pkValue='".makeSafe($selected_id)."'");
		$ownerMemberID=sqlValue("select lcase(memberID) from membership_userrecords where tableName='bookings' and pkValue='".makeSafe($selected_id)."'");
		if($arrPerm[2]==1 && getLoggedMemberID()!=$ownerMemberID){
			return "";
		}
		if($arrPerm[2]==2 && getLoggedGroupID()!=$ownerGroupID){
			return "";
		}


		if(($arrPerm[3]==1 && $ownerMemberID==getLoggedMemberID()) || ($arrPerm[3]==2 && $ownerGroupID==getLoggedGroupID()) || $arrPerm[3]==3){
			$AllowUpdate=1;
		}else{
			$AllowUpdate=0;
		}

		$res = sql("select * from `bookings` where `id`='".makeSafe($selected_id)."'", $eo);
		if(!($row = db_fetch_array($res))){
			return error_message($Translation['No records found'], 'bookings_view.php', false);
		}
		$urow = $row;
		$hc = new CI_Input();
		$row = $hc->xss_clean($row);
		$combo_id_number->SelectedData = $row['id_number'];
		$combo_bus->SelectedData = $row['bus'];
		$combo_seat->SelectedData = $row['seat'];
		$combo_date_booked->DefaultDate = $row['date_booked'];
	}else{
		$combo_id_number->SelectedData = $filterer_id_number;
		$combo_bus->SelectedData = $filterer_bus;
		$combo_seat->SelectedData = $filterer_seat;
	}
	$combo_id_number->HTML = '<span id="id_number-container' . $rnd1 . '"></span><input type="hidden" name="id_number" id="id_number' . $rnd1 . '" value="' . html_attr($combo_id_number->SelectedData) . '">';
	$combo_id_number->MatchText = '<span id="id_number-container-readonly' . $rnd1 . '"></span><input type="hidden" name="id_number" id="id_number' . $rnd1 . '" value="' . html_attr($combo_id_number->SelectedData) . '">';
	$combo_bus->HTML = '<span id="bus-container' . $rnd1 . '"></span><input type="hidden" name="bus" id="bus' . $rnd1 . '" value="' . html_attr($combo_bus->SelectedData) . '">';
	$combo_bus->MatchText = '<span id="bus-container-readonly' . $rnd1 . '"></span><input type="hidden" name="bus" id="bus' . $rnd1 . '" value="' . html_attr($combo_bus->SelectedData) . '">';
	$combo_seat->HTML = '<span id="seat-container' . $rnd1 . '"></span><input type="hidden" name="seat" id="seat' . $rnd1 . '" value="' . html_attr($combo_seat->SelectedData) . '">';
	$combo_seat->MatchText = '<span id="seat-container-readonly' . $rnd1 . '"></span><input type="hidden" name="seat" id="seat' . $rnd1 . '" value="' . html_attr($combo_seat->SelectedData) . '">';

	ob_start();
	?>

	<script>

		AppGini.current_id_number__RAND__ = { text: "", value: "<?php echo addslashes($selected_id ? $urow['id_number'] : $filterer_id_number); ?>"};
		AppGini.current_bus__RAND__ = { text: "", value: "<?php echo addslashes($selected_id ? $urow['bus'] : $filterer_bus); ?>"};
		AppGini.current_seat__RAND__ = { text: "", value: "<?php echo addslashes($selected_id ? $urow['seat'] : $filterer_seat); ?>"};

		jQuery(function() {
			setTimeout(function(){
				if(typeof(id_number_reload__RAND__) == 'function') id_number_reload__RAND__();
				if(typeof(bus_reload__RAND__) == 'function') bus_reload__RAND__();
				if(typeof(seat_reload__RAND__) == 'function') seat_reload__RAND__();
			}, 10); 
		});
		function id_number_reload__RAND__(){
		<?php if(($AllowUpdate || $AllowInsert) && !$dvprint){ ?>

			$j("#id_number-container__RAND__").select2({

				initSelection: function(e, c){
					$j.ajax({
						url: 'ajax_combo.php',
						dataType: 'json',
						data: { id: AppGini.current_id_number__RAND__.value, t: 'bookings', f: 'id_number' },
						success: function(resp){
							c({
								id: resp.results[0].id,
								text: resp.results[0].text
							});
							$j('[name="id_number"]').val(resp.results[0].id);
							$j('[id=id_number-container-readonly__RAND__]').html('<span id="id_number-match-text">' + resp.results[0].text + '</span>');
							if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=customers_view_parent]').hide(); }else{ $j('.btn[id=customers_view_parent]').show(); }


							if(typeof(id_number_update_autofills__RAND__) == 'function') id_number_update_autofills__RAND__();
						}
					});
				},
				width: '100%',
				formatNoMatches: function(term){ /* */ return '<?php echo addslashes($Translation['No matches found!']); ?>'; },
				minimumResultsForSearch: 10,
				loadMorePadding: 200,
				ajax: {
					url: 'ajax_combo.php',
					dataType: 'json',
					cache: true,
					data: function(term, page){ /* */ return { s: term, p: page, t: 'bookings', f: 'id_number' }; },
					results: function(resp, page){ /* */ return resp; }
				},
				escapeMarkup: function(str){ /* */ return str; }
			}).on('change', function(e){
				AppGini.current_id_number__RAND__.value = e.added.id;
				AppGini.current_id_number__RAND__.text = e.added.text;
				$j('[name="id_number"]').val(e.added.id);
				if(e.added.id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=customers_view_parent]').hide(); }else{ $j('.btn[id=customers_view_parent]').show(); }


				if(typeof(id_number_update_autofills__RAND__) == 'function') id_number_update_autofills__RAND__();
			});

			if(!$j("#id_number-container__RAND__").length){
				$j.ajax({
					url: 'ajax_combo.php',
					dataType: 'json',
					data: { id: AppGini.current_id_number__RAND__.value, t: 'bookings', f: 'id_number' },
					success: function(resp){
						$j('[name="id_number"]').val(resp.results[0].id);
						$j('[id=id_number-container-readonly__RAND__]').html('<span id="id_number-match-text">' + resp.results[0].text + '</span>');
						if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=customers_view_parent]').hide(); }else{ $j('.btn[id=customers_view_parent]').show(); }

						if(typeof(id_number_update_autofills__RAND__) == 'function') id_number_update_autofills__RAND__();
					}
				});
			}

		<?php }else{ ?>

			$j.ajax({
				url: 'ajax_combo.php',
				dataType: 'json',
				data: { id: AppGini.current_id_number__RAND__.value, t: 'bookings', f: 'id_number' },
				success: function(resp){
					$j('[id=id_number-container__RAND__], [id=id_number-container-readonly__RAND__]').html('<span id="id_number-match-text">' + resp.results[0].text + '</span>');
					if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=customers_view_parent]').hide(); }else{ $j('.btn[id=customers_view_parent]').show(); }

					if(typeof(id_number_update_autofills__RAND__) == 'function') id_number_update_autofills__RAND__();
				}
			});
		<?php } ?>

		}
		function bus_reload__RAND__(){
		<?php if(($AllowUpdate || $AllowInsert) && !$dvprint){ ?>

			$j("#bus-container__RAND__").select2({

				initSelection: function(e, c){
					$j.ajax({
						url: 'ajax_combo.php',
						dataType: 'json',
						data: { id: AppGini.current_bus__RAND__.value, t: 'bookings', f: 'bus' },
						success: function(resp){
							c({
								id: resp.results[0].id,
								text: resp.results[0].text
							});
							$j('[name="bus"]').val(resp.results[0].id);
							$j('[id=bus-container-readonly__RAND__]').html('<span id="bus-match-text">' + resp.results[0].text + '</span>');
							if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=availability_view_parent]').hide(); }else{ $j('.btn[id=availability_view_parent]').show(); }


							if(typeof(bus_update_autofills__RAND__) == 'function') bus_update_autofills__RAND__();
						}
					});
				},
				width: '100%',
				formatNoMatches: function(term){ /* */ return '<?php echo addslashes($Translation['No matches found!']); ?>'; },
				minimumResultsForSearch: 10,
				loadMorePadding: 200,
				ajax: {
					url: 'ajax_combo.php',
					dataType: 'json',
					cache: true,
					data: function(term, page){ /* */ return { s: term, p: page, t: 'bookings', f: 'bus' }; },
					results: function(resp, page){ /* */ return resp; }
				},
				escapeMarkup: function(str){ /* */ return str; }
			}).on('change', function(e){
				AppGini.current_bus__RAND__.value = e.added.id;
				AppGini.current_bus__RAND__.text = e.added.text;
				$j('[name="bus"]').val(e.added.id);
				if(e.added.id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=availability_view_parent]').hide(); }else{ $j('.btn[id=availability_view_parent]').show(); }


				if(typeof(bus_update_autofills__RAND__) == 'function') bus_update_autofills__RAND__();
			});

			if(!$j("#bus-container__RAND__").length){
				$j.ajax({
					url: 'ajax_combo.php',
					dataType: 'json',
					data: { id: AppGini.current_bus__RAND__.value, t: 'bookings', f: 'bus' },
					success: function(resp){
						$j('[name="bus"]').val(resp.results[0].id);
						$j('[id=bus-container-readonly__RAND__]').html('<span id="bus-match-text">' + resp.results[0].text + '</span>');
						if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=availability_view_parent]').hide(); }else{ $j('.btn[id=availability_view_parent]').show(); }

						if(typeof(bus_update_autofills__RAND__) == 'function') bus_update_autofills__RAND__();
					}
				});
			}

		<?php }else{ ?>

			$j.ajax({
				url: 'ajax_combo.php',
				dataType: 'json',
				data: { id: AppGini.current_bus__RAND__.value, t: 'bookings', f: 'bus' },
				success: function(resp){
					$j('[id=bus-container__RAND__], [id=bus-container-readonly__RAND__]').html('<span id="bus-match-text">' + resp.results[0].text + '</span>');
					if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=availability_view_parent]').hide(); }else{ $j('.btn[id=availability_view_parent]').show(); }

					if(typeof(bus_update_autofills__RAND__) == 'function') bus_update_autofills__RAND__();
				}
			});
		<?php } ?>

		}
		function seat_reload__RAND__(){
		<?php if(($AllowUpdate || $AllowInsert) && !$dvprint){ ?>

			$j("#seat-container__RAND__").select2({

				initSelection: function(e, c){
					$j.ajax({
						url: 'ajax_combo.php',
						dataType: 'json',
						data: { id: AppGini.current_seat__RAND__.value, t: 'bookings', f: 'seat' },
						success: function(resp){
							c({
								id: resp.results[0].id,
								text: resp.results[0].text
							});
							$j('[name="seat"]').val(resp.results[0].id);
							$j('[id=seat-container-readonly__RAND__]').html('<span id="seat-match-text">' + resp.results[0].text + '</span>');
							if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=seats_view_parent]').hide(); }else{ $j('.btn[id=seats_view_parent]').show(); }


							if(typeof(seat_update_autofills__RAND__) == 'function') seat_update_autofills__RAND__();
						}
					});
				},
				width: '100%',
				formatNoMatches: function(term){ /* */ return '<?php echo addslashes($Translation['No matches found!']); ?>'; },
				minimumResultsForSearch: 10,
				loadMorePadding: 200,
				ajax: {
					url: 'ajax_combo.php',
					dataType: 'json',
					cache: true,
					data: function(term, page){ /* */ return { s: term, p: page, t: 'bookings', f: 'seat' }; },
					results: function(resp, page){ /* */ return resp; }
				},
				escapeMarkup: function(str){ /* */ return str; }
			}).on('change', function(e){
				AppGini.current_seat__RAND__.value = e.added.id;
				AppGini.current_seat__RAND__.text = e.added.text;
				$j('[name="seat"]').val(e.added.id);
				if(e.added.id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=seats_view_parent]').hide(); }else{ $j('.btn[id=seats_view_parent]').show(); }


				if(typeof(seat_update_autofills__RAND__) == 'function') seat_update_autofills__RAND__();
			});

			if(!$j("#seat-container__RAND__").length){
				$j.ajax({
					url: 'ajax_combo.php',
					dataType: 'json',
					data: { id: AppGini.current_seat__RAND__.value, t: 'bookings', f: 'seat' },
					success: function(resp){
						$j('[name="seat"]').val(resp.results[0].id);
						$j('[id=seat-container-readonly__RAND__]').html('<span id="seat-match-text">' + resp.results[0].text + '</span>');
						if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=seats_view_parent]').hide(); }else{ $j('.btn[id=seats_view_parent]').show(); }

						if(typeof(seat_update_autofills__RAND__) == 'function') seat_update_autofills__RAND__();
					}
				});
			}

		<?php }else{ ?>

			$j.ajax({
				url: 'ajax_combo.php',
				dataType: 'json',
				data: { id: AppGini.current_seat__RAND__.value, t: 'bookings', f: 'seat' },
				success: function(resp){
					$j('[id=seat-container__RAND__], [id=seat-container-readonly__RAND__]').html('<span id="seat-match-text">' + resp.results[0].text + '</span>');
					if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=seats_view_parent]').hide(); }else{ $j('.btn[id=seats_view_parent]').show(); }

					if(typeof(seat_update_autofills__RAND__) == 'function') seat_update_autofills__RAND__();
				}
			});
		<?php } ?>

		}
	</script>
	<?php

	$lookups = str_replace('__RAND__', $rnd1, ob_get_contents());
	ob_end_clean();





	if($dvprint){
		$template_file = is_file("./{$TemplateDVP}") ? "./{$TemplateDVP}" : './templates/bookings_templateDVP.html';
		$templateCode = @file_get_contents($template_file);
	}else{
		$template_file = is_file("./{$TemplateDV}") ? "./{$TemplateDV}" : './templates/bookings_templateDV.html';
		$templateCode = @file_get_contents($template_file);
	}


	$templateCode = str_replace('<%%DETAIL_VIEW_TITLE%%>', 'Booking details', $templateCode);
	$templateCode = str_replace('<%%RND1%%>', $rnd1, $templateCode);
	$templateCode = str_replace('<%%EMBEDDED%%>', ($_REQUEST['Embedded'] ? 'Embedded=1' : ''), $templateCode);

	if($AllowInsert){
		if(!$selected_id) $templateCode = str_replace('<%%INSERT_BUTTON%%>', '<button type="submit" class="btn btn-success" id="insert" name="insert_x" value="1" onclick="return bookings_validateData();"><i class="glyphicon glyphicon-plus-sign"></i> ' . $Translation['Save New'] . '</button>', $templateCode);
		$templateCode = str_replace('<%%INSERT_BUTTON%%>', '<button type="submit" class="btn btn-default" id="insert" name="insert_x" value="1" onclick="return bookings_validateData();"><i class="glyphicon glyphicon-plus-sign"></i> ' . $Translation['Save As Copy'] . '</button>', $templateCode);
	}else{
		$templateCode = str_replace('<%%INSERT_BUTTON%%>', '', $templateCode);
	}


	if($_REQUEST['Embedded']){
		$backAction = 'AppGini.closeParentModal(); return false;';
	}else{
		$backAction = '$j(\'form\').eq(0).attr(\'novalidate\', \'novalidate\'); document.myform.reset(); return true;';
	}

	if($selected_id){
		if(!$_REQUEST['Embedded']) $templateCode = str_replace('<%%DVPRINT_BUTTON%%>', '<button type="submit" class="btn btn-default" id="dvprint" name="dvprint_x" value="1" onclick="$$(\'form\')[0].writeAttribute(\'novalidate\', \'novalidate\'); document.myform.reset(); return true;" title="' . html_attr($Translation['Print Preview']) . '"><i class="glyphicon glyphicon-print"></i> ' . $Translation['Print Preview'] . '</button>', $templateCode);
		if($AllowUpdate){
			$templateCode = str_replace('<%%UPDATE_BUTTON%%>', '<button type="submit" class="btn btn-success btn-lg" id="update" name="update_x" value="1" onclick="return bookings_validateData();" title="' . html_attr($Translation['Save Changes']) . '"><i class="glyphicon glyphicon-ok"></i> ' . $Translation['Save Changes'] . '</button>', $templateCode);
		}else{
			$templateCode = str_replace('<%%UPDATE_BUTTON%%>', '', $templateCode);
		}
		if(($arrPerm[4]==1 && $ownerMemberID==getLoggedMemberID()) || ($arrPerm[4]==2 && $ownerGroupID==getLoggedGroupID()) || $arrPerm[4]==3){ 
			$templateCode = str_replace('<%%DELETE_BUTTON%%>', '<button type="submit" class="btn btn-danger" id="delete" name="delete_x" value="1" onclick="return confirm(\'' . $Translation['are you sure?'] . '\');" title="' . html_attr($Translation['Delete']) . '"><i class="glyphicon glyphicon-trash"></i> ' . $Translation['Delete'] . '</button>', $templateCode);
		}else{
			$templateCode = str_replace('<%%DELETE_BUTTON%%>', '', $templateCode);
		}
		$templateCode = str_replace('<%%DESELECT_BUTTON%%>', '<button type="submit" class="btn btn-default" id="deselect" name="deselect_x" value="1" onclick="' . $backAction . '" title="' . html_attr($Translation['Back']) . '"><i class="glyphicon glyphicon-chevron-left"></i> ' . $Translation['Back'] . '</button>', $templateCode);
	}else{
		$templateCode = str_replace('<%%UPDATE_BUTTON%%>', '', $templateCode);
		$templateCode = str_replace('<%%DELETE_BUTTON%%>', '', $templateCode);
		$templateCode = str_replace('<%%DESELECT_BUTTON%%>', ($ShowCancel ? '<button type="submit" class="btn btn-default" id="deselect" name="deselect_x" value="1" onclick="' . $backAction . '" title="' . html_attr($Translation['Back']) . '"><i class="glyphicon glyphicon-chevron-left"></i> ' . $Translation['Back'] . '</button>' : ''), $templateCode);
	}


	if(($selected_id && !$AllowUpdate && !$AllowInsert) || (!$selected_id && !$AllowInsert)){
		$jsReadOnly .= "\tjQuery('#id_number').prop('disabled', true).css({ color: '#555', backgroundColor: '#fff' });\n";
		$jsReadOnly .= "\tjQuery('#id_number_caption').prop('disabled', true).css({ color: '#555', backgroundColor: 'white' });\n";
		$jsReadOnly .= "\tjQuery('#bus').prop('disabled', true).css({ color: '#555', backgroundColor: '#fff' });\n";
		$jsReadOnly .= "\tjQuery('#bus_caption').prop('disabled', true).css({ color: '#555', backgroundColor: 'white' });\n";
		$jsReadOnly .= "\tjQuery('#seat').prop('disabled', true).css({ color: '#555', backgroundColor: '#fff' });\n";
		$jsReadOnly .= "\tjQuery('#seat_caption').prop('disabled', true).css({ color: '#555', backgroundColor: 'white' });\n";
		$jsReadOnly .= "\tjQuery('#luggage').prop('disabled', true);\n";
		$jsReadOnly .= "\tjQuery('.select2-container').hide();\n";

		$noUploads = true;
	}elseif($AllowInsert){
		$jsEditable .= "\tjQuery('form').eq(0).data('already_changed', true);"; 
			$jsEditable .= "\tjQuery('form').eq(0).data('already_changed', false);";
	}


	$templateCode = str_replace('<%%COMBO(id_number)%%>', $combo_id_number->HTML, $templateCode);
	$templateCode = str_replace('<%%COMBOTEXT(id_number)%%>', $combo_id_number->MatchText, $templateCode);
	$templateCode = str_replace('<%%URLCOMBOTEXT(id_number)%%>', urlencode($combo_id_number->MatchText), $templateCode);
	$templateCode = str_replace('<%%COMBO(bus)%%>', $combo_bus->HTML, $templateCode);
	$templateCode = str_replace('<%%COMBOTEXT(bus)%%>', $combo_bus->MatchText, $templateCode);
	$templateCode = str_replace('<%%URLCOMBOTEXT(bus)%%>', urlencode($combo_bus->MatchText), $templateCode);
	$templateCode = str_replace('<%%COMBO(seat)%%>', $combo_seat->HTML, $templateCode);
	$templateCode = str_replace('<%%COMBOTEXT(seat)%%>', $combo_seat->MatchText, $templateCode);
	$templateCode = str_replace('<%%URLCOMBOTEXT(seat)%%>', urlencode($combo_seat->MatchText), $templateCode);
	$templateCode = str_replace('<%%COMBO(date_booked)%%>', ($selected_id && !$arrPerm[3] ? '<div class="form-control-static">' . $combo_date_booked->GetHTML(true) . '</div>' : $combo_date_booked->GetHTML()), $templateCode);
	$templateCode = str_replace('<%%COMBOTEXT(date_booked)%%>', $combo_date_booked->GetHTML(true), $templateCode);


	$lookup_fields = array(  'id_number' => array('customers', 'Id number'), 'bus' => array('availability', 'Bus'), 'seat' => array('seats', 'Seat'));
	foreach($lookup_fields as $luf => $ptfc){
		$pt_perm = getTablePermissions($ptfc[0]);


		if($pt_perm['view'] || $pt_perm['edit']){
			$templateCode = str_replace("<%%PLINK({$luf})%%>", '<button type="button" class="btn btn-default view_parent hspacer-md" id="' . $ptfc[0] . '_view_parent" title="' . html_attr($Translation['View'] . ' ' . $ptfc[1]) . '"><i class="glyphicon glyphicon-eye-open"></i></button>', $templateCode);
		}


		if($pt_perm['insert'] && !$_REQUEST['Embedded']){
			$templateCode = str_replace("<%%ADDNEW({$ptfc[0]})%%>", '<button type="button" class="btn btn-success add_new_parent hspacer-md" id="' . $ptfc[0] . '_add_new" title="' . html_attr($Translation['Add New'] . ' ' . $ptfc[1]) . '"><i class="glyphicon glyphicon-plus-sign"></i></button>', $templateCode);
		}
	}


	$templateCode = str_replace('<%%UPLOADFILE(id)%%>', '', $templateCode);
	$templateCode = str_replace('<%%UPLOADFILE(id_number)%%>', '', $templateCode);
	$templateCode = str_replace('<%%UPLOADFILE(bus)%%>', '', $templateCode);
	$templateCode = str_replace('<%%UPLOADFILE(seat)%%>', '', $templateCode);
	$templateCode = str_replace('<%%UPLOADFILE(luggage)%%>', '', $templateCode);
	$templateCode = str_replace('<%%UPLOADFILE(date_booked)%%>', '', $templateCode);


	if($selected_id){
		if( $dvprint) $templateCode = str_replace('<%%VALUE(id)%%>', safe_html($urow['id']), $templateCode);
		if(!$dvprint) $templateCode = str_replace('<%%VALUE(id)%%>', html_attr($row['id']), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(id)%%>', urlencode($urow['id']), $templateCode);
		if( $dvprint) $templateCode = str_replace('<%%VALUE(id_number)%%>', safe_html($urow['id_number']), $templateCode);
		if(!$dvprint) $templateCode = str_replace('<%%VALUE(id_number)%%>', html_attr($row['id_number']), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(id_number)%%>', urlencode($urow['id_number']), $templateCode);
		if( $dvprint) $templateCode = str_replace('<%%VALUE(bus)%%>', safe_html($urow['bus']), $templateCode);
		if(!$dvprint) $templateCode = str_replace('<%%VALUE(bus)%%>', html_attr($row['bus']), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(bus)%%>', urlencode($urow['bus']), $templateCode);
		if( $dvprint) $templateCode = str_replace('<%%VALUE(seat)%%>', safe_html($urow['seat']), $templateCode);
		if(!$dvprint) $templateCode = str_replace('<%%VALUE(seat)%%>', html_attr($row['seat']), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(seat)%%>', urlencode($urow['seat']), $templateCode);
		$templateCode = str_replace('<%%CHECKED(luggage)%%>', ($row['luggage'] ? "checked" : ""), $templateCode);
		$templateCode = str_replace('<%%VALUE(date_booked)%%>', @date('m/d/Y', @strtotime(html_attr($row['date_booked']))), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(date_booked)%%>', urlencode(@date('m/d/Y', @strtotime(html_attr($urow['date_booked'])))), $templateCode);
	}else{
		$templateCode = str_replace('<%%VALUE(id)%%>', '', $templateCode);
		$templateCode = str_replace('<%%URLVALUE(id)%%>', urlencode(''), $templateCode);
		$templateCode = str_replace('<%%VALUE(id_number)%%>', '', $templateCode);
		$templateCode = str_replace('<%%URLVALUE(id_number)%%>', urlencode(''), $templateCode);
		$templateCode = str_replace('<%%VALUE(bus)%%>', '', $templateCode);
		$templateCode = str_replace('<%%URLVALUE(bus)%%>', urlencode(''), $templateCode);
		$templateCode = str_replace('<%%VALUE(seat)%%>', '', $templateCode);
		$templateCode = str_replace('<%%URLVALUE(seat)%%>', urlencode(''), $templateCode);
		$templateCode = str_replace('<%%CHECKED(luggage)%%>', '', $templateCode);
		$templateCode = str_replace('<%%VALUE(date_booked)%%>', '<%%creationDate%%>', $templateCode);
		$templateCode = str_replace('<%%URLVALUE(date_booked)%%>', urlencode('<%%creationDate%%>'), $templateCode);
	}


	foreach($Translation as $symbol=>$trans){
		$templateCode = str_replace("<%%TRANSLATION($symbol)%%>", $trans, $templateCode);
	}


	$templateCode = str_replace('<%%', '<!-- ', $templateCode);
	$templateCode = str_replace('%%>', ' -->', $templateCode);


	if($_REQUEST['dvprint_x'] == ''){
		$templateCode .= "\n\n<script>\$j(function(){\n";
		$arrTables = getTableList();
		foreach($arrTables as $name => $caption){
			$templateCode .= "\t\$j('#{$name}_link').removeClass('hidden');\n";
			$templateCode .= "\t\$j('#xs_{$name}_link').removeClass('hidden');\n";
		}

		$templateCode .= $jsReadOnly;
		$templateCode .= $jsEditable;

		if(!$selected_id){
		}

		$templateCode.="\n});</script>\n";
	}


	$templateCode .= '<script>';
	$templateCode .= '$j(function() {';

	$templateCode .= "\tid_number_update_autofills$rnd1 = function(){\n";
	$templateCode .= "\t\t\$j.ajax({\n";
	if($dvprint){
		$templateCode .= "\t\t\turl: 'bookings_autofill.php?rnd1=$rnd1&mfk=id_number&id=' + encodeURIComponent('".addslashes($row['id_number'])."'),\n";
		$templateCode .= "\t\t\tcontentType: 'application/x-www-form-urlencoded; charset=" . datalist_db_encoding . "', type: 'GET'\n";
	}else{
		$templateCode .= "\t\t\turl: 'bookings_autofill.php?rnd1=$rnd1&mfk=id_number&id=' + encodeURIComponent(AppGini.current_id_number{$rnd1}.value),\n";
		$templateCode .= "\t\t\tcontentType: 'application/x-www-form-urlencoded; charset=" . datalist_db_encoding . "', type: 'GET', beforeSend: function(){ /* */ \$j('#id_number$rnd1').prop('disabled', true); \$j('#id_numberLoading').html('<img src=loading.gif align=top>'); }, complete: function(){".(($arrPerm[1] || (($arrPerm[3] == 1 && $ownerMemberID == getLoggedMemberID()) || ($arrPerm[3] == 2 && $ownerGroupID == getLoggedGroupID()) || $arrPerm[3] == 3)) ? "\$j('#id_number$rnd1').prop('disabled', false); " : "\$j('#id_number$rnd1').prop('disabled', true); ")."\$j('#id_numberLoading').html('');}\n";
	}
	$templateCode.="\t\t});\n";
	$templateCode.="\t};\n";
	if(!$dvprint) $templateCode.="\tif(\$j('#id_number_caption').length) \$j('#id_number_caption').click(function(){ /* */ id_number_update_autofills$rnd1(); });\n";

	$templateCode .= "\tbus_update_autofills$rnd1 = function(){\n";
	$templateCode .= "\t\t\$j.ajax({\n";
	if($dvprint){
		$templateCode .= "\t\t\turl: 'bookings_autofill.php?rnd1=$rnd1&mfk=bus&id=' + encodeURIComponent('".addslashes($row['bus'])."'),\n";
		$templateCode .= "\t\t\tcontentType: 'application/x-www-form-urlencoded; charset=" . datalist_db_encoding . "', type: 'GET'\n";
	}else{
		$templateCode .= "\t\t\turl: 'bookings_autofill.php?rnd1=$rnd1&mfk=bus&id=' + encodeURIComponent(AppGini.current_bus{$rnd1}.value),\n";
		$templateCode .= "\t\t\tcontentType: 'application/x-www-form-urlencoded; charset=" . datalist_db_encoding . "', type: 'GET', beforeSend: function(){ /* */ \$j('#bus$rnd1').prop('disabled', true); \$j('#busLoading').html('<img src=loading.gif align=top>'); }, complete: function(){".(($arrPerm[1] || (($arrPerm[3] == 1 && $ownerMemberID == getLoggedMemberID()) || ($arrPerm[3] == 2 && $ownerGroupID == getLoggedGroupID()) || $arrPerm[3] == 3)) ? "\$j('#bus$rnd1').prop('disabled', false); " : "\$j('#bus$rnd1').prop('disabled', true); ")."\$j('#busLoading').html('');}\n";
	}
	$templateCode.="\t\t});\n";
	$templateCode.="\t};\n";
	if(!$dvprint) $templateCode.="\tif(\$j('#bus_caption').length) \$j('#bus_caption').click(function(){ /* */ bus_update_autofills$rnd1(); });\n";


	$templateCode.="});";
	$templateCode.="</script>";
	$templateCode .= $lookups;




	$templateCode = preg_replace('/blank.gif" data-lightbox=".*?"/', 'blank.gif"', $templateCode);


	$templateCode=preg_replace('/<a .*?href="mailto:".*?<\/a>/', '', $templateCode);


	$rdata = $jdata = get_defaults('bookings');
	if($selected_id){
		$jdata = get_joined_record('bookings', $selected_id);
		if($jdata === false) $jdata = get_defaults('bookings');
		$rdata = $row;
	}
	$cache_data = array(
		'rdata' => array_map('nl2br', array_map('html_attr_tags_ok', $rdata)),
		'jdata' => array_map('nl2br', array_map('html_attr_tags_ok', $jdata))
	);
	$templateCode .= loadView('bookings-ajax-cache', $cache_data);


	if(function_exists('bookings_dv')){
		$args=array();
		bookings_dv(($selected_id ? $selected_id : FALSE), getMemberInfo(), $templateCode, $args);
	}

	return $templateCode;
}
?>
