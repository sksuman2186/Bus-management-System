<?php

function availability_insert(){
	global $Translation;

	$arrPerm=getTablePermissions('availability');
	if(!$arrPerm[1]){
		return false;
	}

	$data['bus'] = makeSafe($_REQUEST['bus']);
		if($data['bus'] == empty_lookup_value){ $data['bus'] = ''; }
	$data['route'] = makeSafe($_REQUEST['route']);
		if($data['route'] == empty_lookup_value){ $data['route'] = ''; }
	$data['amount'] = makeSafe($_REQUEST['route']);
		if($data['amount'] == empty_lookup_value){ $data['amount'] = ''; }
	$data['date'] = intval($_REQUEST['dateYear']) . '-' . intval($_REQUEST['dateMonth']) . '-' . intval($_REQUEST['dateDay']);
	$data['date'] = parseMySQLDate($data['date'], '1');
	$data['time'] = makeSafe($_REQUEST['time']);
		if($data['time'] == empty_lookup_value){ $data['time'] = ''; }
	$data['time'] = time24($data['time']);
	$data['status'] = makeSafe($_REQUEST['status']);
		if($data['status'] == empty_lookup_value){ $data['status'] = ''; }


	if(function_exists('availability_before_insert')){
		$args=array();
		if(!availability_before_insert($data, getMemberInfo(), $args)){ return false; }
	}

	$o = array('silentErrors' => true);
	sql('insert into `availability` set       `bus`=' . (($data['bus'] !== '' && $data['bus'] !== NULL) ? "'{$data['bus']}'" : 'NULL') . ', `route`=' . (($data['route'] !== '' && $data['route'] !== NULL) ? "'{$data['route']}'" : 'NULL') . ', `amount`=' . (($data['amount'] !== '' && $data['amount'] !== NULL) ? "'{$data['amount']}'" : 'NULL') . ', `date`=' . (($data['date'] !== '' && $data['date'] !== NULL) ? "'{$data['date']}'" : 'NULL') . ', `time`=' . (($data['time'] !== '' && $data['time'] !== NULL) ? "'{$data['time']}'" : 'NULL') . ', `status`=' . (($data['status'] !== '' && $data['status'] !== NULL) ? "'{$data['status']}'" : 'NULL'), $o);
	if($o['error']!=''){
		echo $o['error'];
		echo "<a href=\"availability_view.php?addNew_x=1\">{$Translation['< back']}</a>";
		exit;
	}

	$recID = db_insert_id(db_link());


	if(function_exists('availability_after_insert')){
		$res = sql("select * from `availability` where `id`='" . makeSafe($recID, false) . "' limit 1", $eo);
		if($row = db_fetch_assoc($res)){
			$data = array_map('makeSafe', $row);
		}
		$data['selectedID'] = makeSafe($recID, false);
		$args=array();
		if(!availability_after_insert($data, getMemberInfo(), $args)){ return $recID; }
	}


	set_record_owner('availability', $recID, getLoggedMemberID());

	return $recID;
}

function availability_delete($selected_id, $AllowDeleteOfParents=false, $skipChecks=false){

	global $Translation;
	$selected_id=makeSafe($selected_id);


	$arrPerm=getTablePermissions('availability');
	$ownerGroupID=sqlValue("select groupID from membership_userrecords where tableName='availability' and pkValue='$selected_id'");
	$ownerMemberID=sqlValue("select lcase(memberID) from membership_userrecords where tableName='availability' and pkValue='$selected_id'");
	if(($arrPerm[4]==1 && $ownerMemberID==getLoggedMemberID()) || ($arrPerm[4]==2 && $ownerGroupID==getLoggedGroupID()) || $arrPerm[4]==3){ 
		
	}else{
		return $Translation['You don\'t have enough permissions to delete this record'];
	}


	if(function_exists('availability_before_delete')){
		$args=array();
		if(!availability_before_delete($selected_id, $skipChecks, getMemberInfo(), $args))
			return $Translation['Couldn\'t delete this record'];
	}


	$res = sql("select `id` from `availability` where `id`='$selected_id'", $eo);
	$id = db_fetch_row($res);
	$rires = sql("select count(1) from `bookings` where `bus`='".addslashes($id[0])."'", $eo);
	$rirow = db_fetch_row($rires);
	if($rirow[0] && !$AllowDeleteOfParents && !$skipChecks){
		$RetMsg = $Translation["couldn't delete"];
		$RetMsg = str_replace("<RelatedRecords>", $rirow[0], $RetMsg);
		$RetMsg = str_replace("<TableName>", "bookings", $RetMsg);
		return $RetMsg;
	}elseif($rirow[0] && $AllowDeleteOfParents && !$skipChecks){
		$RetMsg = $Translation["confirm delete"];
		$RetMsg = str_replace("<RelatedRecords>", $rirow[0], $RetMsg);
		$RetMsg = str_replace("<TableName>", "bookings", $RetMsg);
		$RetMsg = str_replace("<Delete>", "<input type=\"button\" class=\"button\" value=\"".$Translation['yes']."\" onClick=\"window.location='availability_view.php?SelectedID=".urlencode($selected_id)."&delete_x=1&confirmed=1';\">", $RetMsg);
		$RetMsg = str_replace("<Cancel>", "<input type=\"button\" class=\"button\" value=\"".$Translation['no']."\" onClick=\"window.location='availability_view.php?SelectedID=".urlencode($selected_id)."';\">", $RetMsg);
		return $RetMsg;
	}

	sql("delete from `availability` where `id`='$selected_id'", $eo);


	if(function_exists('availability_after_delete')){
		$args=array();
		availability_after_delete($selected_id, getMemberInfo(), $args);
	}


	sql("delete from membership_userrecords where tableName='availability' and pkValue='$selected_id'", $eo);
}

function availability_update($selected_id){
	global $Translation;


	$arrPerm=getTablePermissions('availability');
	$ownerGroupID=sqlValue("select groupID from membership_userrecords where tableName='availability' and pkValue='".makeSafe($selected_id)."'");
	$ownerMemberID=sqlValue("select lcase(memberID) from membership_userrecords where tableName='availability' and pkValue='".makeSafe($selected_id)."'");
	if(($arrPerm[3]==1 && $ownerMemberID==getLoggedMemberID()) || ($arrPerm[3]==2 && $ownerGroupID==getLoggedGroupID()) || $arrPerm[3]==3){ 
		
	}else{
		return false;
	}

	$data['bus'] = makeSafe($_REQUEST['bus']);
		if($data['bus'] == empty_lookup_value){ $data['bus'] = ''; }
	$data['route'] = makeSafe($_REQUEST['route']);
		if($data['route'] == empty_lookup_value){ $data['route'] = ''; }
	$data['amount'] = makeSafe($_REQUEST['route']);
		if($data['amount'] == empty_lookup_value){ $data['amount'] = ''; }
	$data['date'] = intval($_REQUEST['dateYear']) . '-' . intval($_REQUEST['dateMonth']) . '-' . intval($_REQUEST['dateDay']);
	$data['date'] = parseMySQLDate($data['date'], '1');
	$data['time'] = makeSafe($_REQUEST['time']);
		if($data['time'] == empty_lookup_value){ $data['time'] = ''; }
	$data['time'] = time24($data['time']);
	$data['status'] = makeSafe($_REQUEST['status']);
		if($data['status'] == empty_lookup_value){ $data['status'] = ''; }
	$data['selectedID']=makeSafe($selected_id);


	if(function_exists('availability_before_update')){
		$args=array();
		if(!availability_before_update($data, getMemberInfo(), $args)){ return false; }
	}

	$o=array('silentErrors' => true);
	sql('update `availability` set       `bus`=' . (($data['bus'] !== '' && $data['bus'] !== NULL) ? "'{$data['bus']}'" : 'NULL') . ', `route`=' . (($data['route'] !== '' && $data['route'] !== NULL) ? "'{$data['route']}'" : 'NULL') . ', `amount`=' . (($data['amount'] !== '' && $data['amount'] !== NULL) ? "'{$data['amount']}'" : 'NULL') . ', `date`=' . (($data['date'] !== '' && $data['date'] !== NULL) ? "'{$data['date']}'" : 'NULL') . ', `time`=' . (($data['time'] !== '' && $data['time'] !== NULL) ? "'{$data['time']}'" : 'NULL') . ', `status`=' . (($data['status'] !== '' && $data['status'] !== NULL) ? "'{$data['status']}'" : 'NULL') . " where `id`='".makeSafe($selected_id)."'", $o);
	if($o['error']!=''){
		echo $o['error'];
		echo '<a href="availability_view.php?SelectedID='.urlencode($selected_id)."\">{$Translation['< back']}</a>";
		exit;
	}



	if(function_exists('availability_after_update')){
		$res = sql("SELECT * FROM `availability` WHERE `id`='{$data['selectedID']}' LIMIT 1", $eo);
		if($row = db_fetch_assoc($res)){
			$data = array_map('makeSafe', $row);
		}
		$data['selectedID'] = $data['id'];
		$args = array();
		if(!availability_after_update($data, getMemberInfo(), $args)){ return; }
	}


	sql("update membership_userrecords set dateUpdated='".time()."' where tableName='availability' and pkValue='".makeSafe($selected_id)."'", $eo);

}

function availability_form($selected_id = '', $AllowUpdate = 1, $AllowInsert = 1, $AllowDelete = 1, $ShowCancel = 0, $TemplateDV = '', $TemplateDVP = ''){
	
	global $Translation;


	$arrPerm=getTablePermissions('availability');
	if(!$arrPerm[1] && $selected_id==''){ return ''; }
	$AllowInsert = ($arrPerm[1] ? true : false);

	$dvprint = false;
	if($selected_id && $_REQUEST['dvprint_x'] != ''){
		$dvprint = true;
	}

	$filterer_bus = thisOr(undo_magic_quotes($_REQUEST['filterer_bus']), '');
	$filterer_route = thisOr(undo_magic_quotes($_REQUEST['filterer_route']), '');




	$rnd1 = ($dvprint ? rand(1000000, 9999999) : '');

	$combo_bus = new DataCombo;

	$combo_route = new DataCombo;

	$combo_date = new DateCombo;
	$combo_date->DateFormat = "mdy";
	$combo_date->MinYear = 1900;
	$combo_date->MaxYear = 2100;
	$combo_date->DefaultDate = parseMySQLDate('1', '1');
	$combo_date->MonthNames = $Translation['month names'];
	$combo_date->NamePrefix = 'date';

	$combo_status = new Combo;
	$combo_status->ListType = 0;
	$combo_status->MultipleSeparator = ', ';
	$combo_status->ListBoxHeight = 10;
	$combo_status->RadiosPerLine = 1;
	if(is_file(dirname(__FILE__).'/hooks/availability.status.csv')){
		$status_data = addslashes(implode('', @file(dirname(__FILE__).'/hooks/availability.status.csv')));
		$combo_status->ListItem = explode('||', entitiesToUTF8(convertLegacyOptions($status_data)));
		$combo_status->ListData = $combo_status->ListItem;
	}else{
		$combo_status->ListItem = explode('||', entitiesToUTF8(convertLegacyOptions("available;;not available")));
		$combo_status->ListData = $combo_status->ListItem;
	}
	$combo_status->SelectName = 'status';

	if($selected_id){

		if(!$arrPerm[2]){
			return "";
		}

		$ownerGroupID=sqlValue("select groupID from membership_userrecords where tableName='availability' and pkValue='".makeSafe($selected_id)."'");
		$ownerMemberID=sqlValue("select lcase(memberID) from membership_userrecords where tableName='availability' and pkValue='".makeSafe($selected_id)."'");
		if($arrPerm[2]==1 && getLoggedMemberID()!=$ownerMemberID){
			return "";
		}
		if($arrPerm[2]==2 && getLoggedGroupID()!=$ownerGroupID){
			return "";
		}


		if(($arrPerm[3]==1 && $ownerMemberID==getLoggedMemberID()) || ($arrPerm[3]==2 && $ownerGroupID==getLoggedGroupID()) || $arrPerm[3]==3){
			$AllowUpdate=1;
		}else{
			$AllowUpdate=0;
		}

		$res = sql("select * from `availability` where `id`='".makeSafe($selected_id)."'", $eo);
		if(!($row = db_fetch_array($res))){
			return error_message($Translation['No records found'], 'availability_view.php', false);
		}
		$urow = $row; 
		$hc = new CI_Input();
		$row = $hc->xss_clean($row); 
		$combo_bus->SelectedData = $row['bus'];
		$combo_route->SelectedData = $row['route'];
		$combo_date->DefaultDate = $row['date'];
		$combo_status->SelectedData = $row['status'];
	}else{
		$combo_bus->SelectedData = $filterer_bus;
		$combo_route->SelectedData = $filterer_route;
		$combo_status->SelectedText = ( $_REQUEST['FilterField'][1]=='7' && $_REQUEST['FilterOperator'][1]=='<=>' ? (get_magic_quotes_gpc() ? stripslashes($_REQUEST['FilterValue'][1]) : $_REQUEST['FilterValue'][1]) : "");
	}
	$combo_bus->HTML = '<span id="bus-container' . $rnd1 . '"></span><input type="hidden" name="bus" id="bus' . $rnd1 . '" value="' . html_attr($combo_bus->SelectedData) . '">';
	$combo_bus->MatchText = '<span id="bus-container-readonly' . $rnd1 . '"></span><input type="hidden" name="bus" id="bus' . $rnd1 . '" value="' . html_attr($combo_bus->SelectedData) . '">';
	$combo_route->HTML = '<span id="route-container' . $rnd1 . '"></span><input type="hidden" name="route" id="route' . $rnd1 . '" value="' . html_attr($combo_route->SelectedData) . '">';
	$combo_route->MatchText = '<span id="route-container-readonly' . $rnd1 . '"></span><input type="hidden" name="route" id="route' . $rnd1 . '" value="' . html_attr($combo_route->SelectedData) . '">';
	$combo_status->Render();

	ob_start();
	?>

	<script>

		AppGini.current_bus__RAND__ = { text: "", value: "<?php echo addslashes($selected_id ? $urow['bus'] : $filterer_bus); ?>"};
		AppGini.current_route__RAND__ = { text: "", value: "<?php echo addslashes($selected_id ? $urow['route'] : $filterer_route); ?>"};

		jQuery(function() {
			setTimeout(function(){
				if(typeof(bus_reload__RAND__) == 'function') bus_reload__RAND__();
				if(typeof(route_reload__RAND__) == 'function') route_reload__RAND__();
			}, 10); 
		});
		function bus_reload__RAND__(){
		<?php if(($AllowUpdate || $AllowInsert) && !$dvprint){ ?>

			$j("#bus-container__RAND__").select2({

				initSelection: function(e, c){
					$j.ajax({
						url: 'ajax_combo.php',
						dataType: 'json',
						data: { id: AppGini.current_bus__RAND__.value, t: 'availability', f: 'bus' },
						success: function(resp){
							c({
								id: resp.results[0].id,
								text: resp.results[0].text
							});
							$j('[name="bus"]').val(resp.results[0].id);
							$j('[id=bus-container-readonly__RAND__]').html('<span id="bus-match-text">' + resp.results[0].text + '</span>');
							if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=buses_view_parent]').hide(); }else{ $j('.btn[id=buses_view_parent]').show(); }


							if(typeof(bus_update_autofills__RAND__) == 'function') bus_update_autofills__RAND__();
						}
					});
				},
				width: '100%',
				formatNoMatches: function(term){ /* */ return '<?php echo addslashes($Translation['No matches found!']); ?>'; },
				minimumResultsForSearch: 10,
				loadMorePadding: 200,
				ajax: {
					url: 'ajax_combo.php',
					dataType: 'json',
					cache: true,
					data: function(term, page){ /* */ return { s: term, p: page, t: 'availability', f: 'bus' }; },
					results: function(resp, page){ /* */ return resp; }
				},
				escapeMarkup: function(str){ /* */ return str; }
			}).on('change', function(e){
				AppGini.current_bus__RAND__.value = e.added.id;
				AppGini.current_bus__RAND__.text = e.added.text;
				$j('[name="bus"]').val(e.added.id);
				if(e.added.id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=buses_view_parent]').hide(); }else{ $j('.btn[id=buses_view_parent]').show(); }


				if(typeof(bus_update_autofills__RAND__) == 'function') bus_update_autofills__RAND__();
			});

			if(!$j("#bus-container__RAND__").length){
				$j.ajax({
					url: 'ajax_combo.php',
					dataType: 'json',
					data: { id: AppGini.current_bus__RAND__.value, t: 'availability', f: 'bus' },
					success: function(resp){
						$j('[name="bus"]').val(resp.results[0].id);
						$j('[id=bus-container-readonly__RAND__]').html('<span id="bus-match-text">' + resp.results[0].text + '</span>');
						if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=buses_view_parent]').hide(); }else{ $j('.btn[id=buses_view_parent]').show(); }

						if(typeof(bus_update_autofills__RAND__) == 'function') bus_update_autofills__RAND__();
					}
				});
			}

		<?php }else{ ?>

			$j.ajax({
				url: 'ajax_combo.php',
				dataType: 'json',
				data: { id: AppGini.current_bus__RAND__.value, t: 'availability', f: 'bus' },
				success: function(resp){
					$j('[id=bus-container__RAND__], [id=bus-container-readonly__RAND__]').html('<span id="bus-match-text">' + resp.results[0].text + '</span>');
					if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=buses_view_parent]').hide(); }else{ $j('.btn[id=buses_view_parent]').show(); }

					if(typeof(bus_update_autofills__RAND__) == 'function') bus_update_autofills__RAND__();
				}
			});
		<?php } ?>

		}
		function route_reload__RAND__(){
		<?php if(($AllowUpdate || $AllowInsert) && !$dvprint){ ?>

			$j("#route-container__RAND__").select2({

				initSelection: function(e, c){
					$j.ajax({
						url: 'ajax_combo.php',
						dataType: 'json',
						data: { id: AppGini.current_route__RAND__.value, t: 'availability', f: 'route' },
						success: function(resp){
							c({
								id: resp.results[0].id,
								text: resp.results[0].text
							});
							$j('[name="route"]').val(resp.results[0].id);
							$j('[id=route-container-readonly__RAND__]').html('<span id="route-match-text">' + resp.results[0].text + '</span>');
							if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=routes_view_parent]').hide(); }else{ $j('.btn[id=routes_view_parent]').show(); }


							if(typeof(route_update_autofills__RAND__) == 'function') route_update_autofills__RAND__();
						}
					});
				},
				width: '100%',
				formatNoMatches: function(term){ /* */ return '<?php echo addslashes($Translation['No matches found!']); ?>'; },
				minimumResultsForSearch: 10,
				loadMorePadding: 200,
				ajax: {
					url: 'ajax_combo.php',
					dataType: 'json',
					cache: true,
					data: function(term, page){ /* */ return { s: term, p: page, t: 'availability', f: 'route' }; },
					results: function(resp, page){ /* */ return resp; }
				},
				escapeMarkup: function(str){ /* */ return str; }
			}).on('change', function(e){
				AppGini.current_route__RAND__.value = e.added.id;
				AppGini.current_route__RAND__.text = e.added.text;
				$j('[name="route"]').val(e.added.id);
				if(e.added.id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=routes_view_parent]').hide(); }else{ $j('.btn[id=routes_view_parent]').show(); }


				if(typeof(route_update_autofills__RAND__) == 'function') route_update_autofills__RAND__();
			});

			if(!$j("#route-container__RAND__").length){
				$j.ajax({
					url: 'ajax_combo.php',
					dataType: 'json',
					data: { id: AppGini.current_route__RAND__.value, t: 'availability', f: 'route' },
					success: function(resp){
						$j('[name="route"]').val(resp.results[0].id);
						$j('[id=route-container-readonly__RAND__]').html('<span id="route-match-text">' + resp.results[0].text + '</span>');
						if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=routes_view_parent]').hide(); }else{ $j('.btn[id=routes_view_parent]').show(); }

						if(typeof(route_update_autofills__RAND__) == 'function') route_update_autofills__RAND__();
					}
				});
			}

		<?php }else{ ?>

			$j.ajax({
				url: 'ajax_combo.php',
				dataType: 'json',
				data: { id: AppGini.current_route__RAND__.value, t: 'availability', f: 'route' },
				success: function(resp){
					$j('[id=route-container__RAND__], [id=route-container-readonly__RAND__]').html('<span id="route-match-text">' + resp.results[0].text + '</span>');
					if(resp.results[0].id == '<?php echo empty_lookup_value; ?>'){ $j('.btn[id=routes_view_parent]').hide(); }else{ $j('.btn[id=routes_view_parent]').show(); }

					if(typeof(route_update_autofills__RAND__) == 'function') route_update_autofills__RAND__();
				}
			});
		<?php } ?>

		}
	</script>
	<?php

	$lookups = str_replace('__RAND__', $rnd1, ob_get_contents());
	ob_end_clean();





	if($dvprint){
		$template_file = is_file("./{$TemplateDVP}") ? "./{$TemplateDVP}" : './templates/availability_templateDVP.html';
		$templateCode = @file_get_contents($template_file);
	}else{
		$template_file = is_file("./{$TemplateDV}") ? "./{$TemplateDV}" : './templates/availability_templateDV.html';
		$templateCode = @file_get_contents($template_file);
	}


	$templateCode = str_replace('<%%DETAIL_VIEW_TITLE%%>', 'Availability details', $templateCode);
	$templateCode = str_replace('<%%RND1%%>', $rnd1, $templateCode);
	$templateCode = str_replace('<%%EMBEDDED%%>', ($_REQUEST['Embedded'] ? 'Embedded=1' : ''), $templateCode);

	if($AllowInsert){
		if(!$selected_id) $templateCode = str_replace('<%%INSERT_BUTTON%%>', '<button type="submit" class="btn btn-success" id="insert" name="insert_x" value="1" onclick="return availability_validateData();"><i class="glyphicon glyphicon-plus-sign"></i> ' . $Translation['Save New'] . '</button>', $templateCode);
		$templateCode = str_replace('<%%INSERT_BUTTON%%>', '<button type="submit" class="btn btn-default" id="insert" name="insert_x" value="1" onclick="return availability_validateData();"><i class="glyphicon glyphicon-plus-sign"></i> ' . $Translation['Save As Copy'] . '</button>', $templateCode);
	}else{
		$templateCode = str_replace('<%%INSERT_BUTTON%%>', '', $templateCode);
	}


	if($_REQUEST['Embedded']){
		$backAction = 'AppGini.closeParentModal(); return false;';
	}else{
		$backAction = '$j(\'form\').eq(0).attr(\'novalidate\', \'novalidate\'); document.myform.reset(); return true;';
	}

	if($selected_id){
		if(!$_REQUEST['Embedded']) $templateCode = str_replace('<%%DVPRINT_BUTTON%%>', '<button type="submit" class="btn btn-default" id="dvprint" name="dvprint_x" value="1" onclick="$$(\'form\')[0].writeAttribute(\'novalidate\', \'novalidate\'); document.myform.reset(); return true;" title="' . html_attr($Translation['Print Preview']) . '"><i class="glyphicon glyphicon-print"></i> ' . $Translation['Print Preview'] . '</button>', $templateCode);
		if($AllowUpdate){
			$templateCode = str_replace('<%%UPDATE_BUTTON%%>', '<button type="submit" class="btn btn-success btn-lg" id="update" name="update_x" value="1" onclick="return availability_validateData();" title="' . html_attr($Translation['Save Changes']) . '"><i class="glyphicon glyphicon-ok"></i> ' . $Translation['Save Changes'] . '</button>', $templateCode);
		}else{
			$templateCode = str_replace('<%%UPDATE_BUTTON%%>', '', $templateCode);
		}
		if(($arrPerm[4]==1 && $ownerMemberID==getLoggedMemberID()) || ($arrPerm[4]==2 && $ownerGroupID==getLoggedGroupID()) || $arrPerm[4]==3){ 
			$templateCode = str_replace('<%%DELETE_BUTTON%%>', '<button type="submit" class="btn btn-danger" id="delete" name="delete_x" value="1" onclick="return confirm(\'' . $Translation['are you sure?'] . '\');" title="' . html_attr($Translation['Delete']) . '"><i class="glyphicon glyphicon-trash"></i> ' . $Translation['Delete'] . '</button>', $templateCode);
		}else{
			$templateCode = str_replace('<%%DELETE_BUTTON%%>', '', $templateCode);
		}
		$templateCode = str_replace('<%%DESELECT_BUTTON%%>', '<button type="submit" class="btn btn-default" id="deselect" name="deselect_x" value="1" onclick="' . $backAction . '" title="' . html_attr($Translation['Back']) . '"><i class="glyphicon glyphicon-chevron-left"></i> ' . $Translation['Back'] . '</button>', $templateCode);
	}else{
		$templateCode = str_replace('<%%UPDATE_BUTTON%%>', '', $templateCode);
		$templateCode = str_replace('<%%DELETE_BUTTON%%>', '', $templateCode);
		$templateCode = str_replace('<%%DESELECT_BUTTON%%>', ($ShowCancel ? '<button type="submit" class="btn btn-default" id="deselect" name="deselect_x" value="1" onclick="' . $backAction . '" title="' . html_attr($Translation['Back']) . '"><i class="glyphicon glyphicon-chevron-left"></i> ' . $Translation['Back'] . '</button>' : ''), $templateCode);
	}


	if(($selected_id && !$AllowUpdate && !$AllowInsert) || (!$selected_id && !$AllowInsert)){
		$jsReadOnly .= "\tjQuery('#bus').prop('disabled', true).css({ color: '#555', backgroundColor: '#fff' });\n";
		$jsReadOnly .= "\tjQuery('#bus_caption').prop('disabled', true).css({ color: '#555', backgroundColor: 'white' });\n";
		$jsReadOnly .= "\tjQuery('#route').prop('disabled', true).css({ color: '#555', backgroundColor: '#fff' });\n";
		$jsReadOnly .= "\tjQuery('#route_caption').prop('disabled', true).css({ color: '#555', backgroundColor: 'white' });\n";
		$jsReadOnly .= "\tjQuery('#date').prop('readonly', true);\n";
		$jsReadOnly .= "\tjQuery('#dateDay, #dateMonth, #dateYear').prop('disabled', true).css({ color: '#555', backgroundColor: '#fff' });\n";
		$jsReadOnly .= "\tjQuery('#time').replaceWith('<div class=\"form-control-static\" id=\"time\">' + (jQuery('#time').val() || '') + '</div>');\n";
		$jsReadOnly .= "\tjQuery('#status').replaceWith('<div class=\"form-control-static\" id=\"status\">' + (jQuery('#status').val() || '') + '</div>'); jQuery('#status-multi-selection-help').hide();\n";
		$jsReadOnly .= "\tjQuery('.select2-container').hide();\n";

		$noUploads = true;
	}elseif($AllowInsert){
		$jsEditable .= "\tjQuery('form').eq(0).data('already_changed', true);"; 
		$jsEditable .= "\tjQuery('#time').addClass('always_shown').timepicker({ defaultTime: false, showSeconds: true, showMeridian: true, showInputs: false, disableFocus: true, minuteStep: 5 });";
			$jsEditable .= "\tjQuery('form').eq(0).data('already_changed', false);"; 
	}


	$templateCode = str_replace('<%%COMBO(bus)%%>', $combo_bus->HTML, $templateCode);
	$templateCode = str_replace('<%%COMBOTEXT(bus)%%>', $combo_bus->MatchText, $templateCode);
	$templateCode = str_replace('<%%URLCOMBOTEXT(bus)%%>', urlencode($combo_bus->MatchText), $templateCode);
	$templateCode = str_replace('<%%COMBO(route)%%>', $combo_route->HTML, $templateCode);
	$templateCode = str_replace('<%%COMBOTEXT(route)%%>', $combo_route->MatchText, $templateCode);
	$templateCode = str_replace('<%%URLCOMBOTEXT(route)%%>', urlencode($combo_route->MatchText), $templateCode);
	$templateCode = str_replace('<%%COMBO(date)%%>', ($selected_id && !$arrPerm[3] ? '<div class="form-control-static">' . $combo_date->GetHTML(true) . '</div>' : $combo_date->GetHTML()), $templateCode);
	$templateCode = str_replace('<%%COMBOTEXT(date)%%>', $combo_date->GetHTML(true), $templateCode);
	$templateCode = str_replace('<%%COMBO(status)%%>', $combo_status->HTML, $templateCode);
	$templateCode = str_replace('<%%COMBOTEXT(status)%%>', $combo_status->SelectedData, $templateCode);


	$lookup_fields = array(  'bus' => array('buses', 'Bus'), 'route' => array('routes', 'Route'));
	foreach($lookup_fields as $luf => $ptfc){
		$pt_perm = getTablePermissions($ptfc[0]);


		if($pt_perm['view'] || $pt_perm['edit']){
			$templateCode = str_replace("<%%PLINK({$luf})%%>", '<button type="button" class="btn btn-default view_parent hspacer-md" id="' . $ptfc[0] . '_view_parent" title="' . html_attr($Translation['View'] . ' ' . $ptfc[1]) . '"><i class="glyphicon glyphicon-eye-open"></i></button>', $templateCode);
		}


		if($pt_perm['insert'] && !$_REQUEST['Embedded']){
			$templateCode = str_replace("<%%ADDNEW({$ptfc[0]})%%>", '<button type="button" class="btn btn-success add_new_parent hspacer-md" id="' . $ptfc[0] . '_add_new" title="' . html_attr($Translation['Add New'] . ' ' . $ptfc[1]) . '"><i class="glyphicon glyphicon-plus-sign"></i></button>', $templateCode);
		}
	}


	$templateCode = str_replace('<%%UPLOADFILE(id)%%>', '', $templateCode);
	$templateCode = str_replace('<%%UPLOADFILE(bus)%%>', '', $templateCode);
	$templateCode = str_replace('<%%UPLOADFILE(route)%%>', '', $templateCode);
	$templateCode = str_replace('<%%UPLOADFILE(date)%%>', '', $templateCode);
	$templateCode = str_replace('<%%UPLOADFILE(time)%%>', '', $templateCode);
	$templateCode = str_replace('<%%UPLOADFILE(status)%%>', '', $templateCode);


	if($selected_id){
		if( $dvprint) $templateCode = str_replace('<%%VALUE(id)%%>', safe_html($urow['id']), $templateCode);
		if(!$dvprint) $templateCode = str_replace('<%%VALUE(id)%%>', html_attr($row['id']), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(id)%%>', urlencode($urow['id']), $templateCode);
		if( $dvprint) $templateCode = str_replace('<%%VALUE(bus)%%>', safe_html($urow['bus']), $templateCode);
		if(!$dvprint) $templateCode = str_replace('<%%VALUE(bus)%%>', html_attr($row['bus']), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(bus)%%>', urlencode($urow['bus']), $templateCode);
		if( $dvprint) $templateCode = str_replace('<%%VALUE(route)%%>', safe_html($urow['route']), $templateCode);
		if(!$dvprint) $templateCode = str_replace('<%%VALUE(route)%%>', html_attr($row['route']), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(route)%%>', urlencode($urow['route']), $templateCode);
		$templateCode = str_replace('<%%VALUE(date)%%>', @date('m/d/Y', @strtotime(html_attr($row['date']))), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(date)%%>', urlencode(@date('m/d/Y', @strtotime(html_attr($urow['date'])))), $templateCode);
		$templateCode = str_replace('<%%VALUE(time)%%>', time12(html_attr($row['time'])), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(time)%%>', urlencode(time12($urow['time'])), $templateCode);
		if( $dvprint) $templateCode = str_replace('<%%VALUE(status)%%>', safe_html($urow['status']), $templateCode);
		if(!$dvprint) $templateCode = str_replace('<%%VALUE(status)%%>', html_attr($row['status']), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(status)%%>', urlencode($urow['status']), $templateCode);
	}else{
		$templateCode = str_replace('<%%VALUE(id)%%>', '', $templateCode);
		$templateCode = str_replace('<%%URLVALUE(id)%%>', urlencode(''), $templateCode);
		$templateCode = str_replace('<%%VALUE(bus)%%>', '', $templateCode);
		$templateCode = str_replace('<%%URLVALUE(bus)%%>', urlencode(''), $templateCode);
		$templateCode = str_replace('<%%VALUE(route)%%>', '', $templateCode);
		$templateCode = str_replace('<%%URLVALUE(route)%%>', urlencode(''), $templateCode);
		$templateCode = str_replace('<%%VALUE(date)%%>', '1', $templateCode);
		$templateCode = str_replace('<%%URLVALUE(date)%%>', urlencode('1'), $templateCode);
		$templateCode = str_replace('<%%VALUE(time)%%>', time12(''), $templateCode);
		$templateCode = str_replace('<%%URLVALUE(time)%%>', urlencode(time12('')), $templateCode);
		$templateCode = str_replace('<%%VALUE(status)%%>', '', $templateCode);
		$templateCode = str_replace('<%%URLVALUE(status)%%>', urlencode(''), $templateCode);
	}


	foreach($Translation as $symbol=>$trans){
		$templateCode = str_replace("<%%TRANSLATION($symbol)%%>", $trans, $templateCode);
	}


	$templateCode = str_replace('<%%', '<!-- ', $templateCode);
	$templateCode = str_replace('%%>', ' -->', $templateCode);


	if($_REQUEST['dvprint_x'] == ''){
		$templateCode .= "\n\n<script>\$j(function(){\n";
		$arrTables = getTableList();
		foreach($arrTables as $name => $caption){
			$templateCode .= "\t\$j('#{$name}_link').removeClass('hidden');\n";
			$templateCode .= "\t\$j('#xs_{$name}_link').removeClass('hidden');\n";
		}

		$templateCode .= $jsReadOnly;
		$templateCode .= $jsEditable;

		if(!$selected_id){
		}

		$templateCode.="\n});</script>\n";
	}


	$templateCode .= '<script>';
	$templateCode .= '$j(function() {';

	$templateCode .= "\troute_update_autofills$rnd1 = function(){\n";
	$templateCode .= "\t\t\$j.ajax({\n";
	if($dvprint){
		$templateCode .= "\t\t\turl: 'availability_autofill.php?rnd1=$rnd1&mfk=route&id=' + encodeURIComponent('".addslashes($row['route'])."'),\n";
		$templateCode .= "\t\t\tcontentType: 'application/x-www-form-urlencoded; charset=" . datalist_db_encoding . "', type: 'GET'\n";
	}else{
		$templateCode .= "\t\t\turl: 'availability_autofill.php?rnd1=$rnd1&mfk=route&id=' + encodeURIComponent(AppGini.current_route{$rnd1}.value),\n";
		$templateCode .= "\t\t\tcontentType: 'application/x-www-form-urlencoded; charset=" . datalist_db_encoding . "', type: 'GET', beforeSend: function(){ /* */ \$j('#route$rnd1').prop('disabled', true); \$j('#routeLoading').html('<img src=loading.gif align=top>'); }, complete: function(){".(($arrPerm[1] || (($arrPerm[3] == 1 && $ownerMemberID == getLoggedMemberID()) || ($arrPerm[3] == 2 && $ownerGroupID == getLoggedGroupID()) || $arrPerm[3] == 3)) ? "\$j('#route$rnd1').prop('disabled', false); " : "\$j('#route$rnd1').prop('disabled', true); ")."\$j('#routeLoading').html('');}\n";
	}
	$templateCode.="\t\t});\n";
	$templateCode.="\t};\n";
	if(!$dvprint) $templateCode.="\tif(\$j('#route_caption').length) \$j('#route_caption').click(function(){ /* */ route_update_autofills$rnd1(); });\n";


	$templateCode.="});";
	$templateCode.="</script>";
	$templateCode .= $lookups;




	$templateCode = preg_replace('/blank.gif" data-lightbox=".*?"/', 'blank.gif"', $templateCode);


	$templateCode=preg_replace('/<a .*?href="mailto:".*?<\/a>/', '', $templateCode);


	$rdata = $jdata = get_defaults('availability');
	if($selected_id){
		$jdata = get_joined_record('availability', $selected_id);
		if($jdata === false) $jdata = get_defaults('availability');
		$rdata = $row;
	}
	$cache_data = array(
		'rdata' => array_map('nl2br', array_map('html_attr_tags_ok', $rdata)),
		'jdata' => array_map('nl2br', array_map('html_attr_tags_ok', $jdata))
	);
	$templateCode .= loadView('availability-ajax-cache', $cache_data);


	if(function_exists('availability_dv')){
		$args=array();
		availability_dv(($selected_id ? $selected_id : FALSE), getMemberInfo(), $templateCode, $args);
	}

	return $templateCode;
}
?>
