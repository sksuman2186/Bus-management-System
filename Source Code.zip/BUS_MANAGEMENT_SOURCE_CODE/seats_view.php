<?php



	$currDir=dirname(__FILE__);
	include("$currDir/defaultLang.php");
	include("$currDir/language.php");
	include("$currDir/lib.php");
	@include("$currDir/hooks/seats.php");
	include("$currDir/seats_dml.php");


	$perm=getTablePermissions('seats');
	if(!$perm[0]){
		echo error_message($Translation['tableAccessDenied'], false);
		echo '<script>setTimeout("window.location=\'index.php?signOut=1\'", 2000);</script>';
		exit;
	}

	$x = new DataList;
	$x->TableName = "seats";


	$x->QueryFieldsTV = array(   
		"`seats`.`id`" => "id",
		"`seats`.`name`" => "name"
	);

	$x->SortFields = array(   
		1 => '`seats`.`id`',
		2 => 2
	);


	$x->QueryFieldsCSV = array(   
		"`seats`.`id`" => "id",
		"`seats`.`name`" => "name"
	);

	$x->QueryFieldsFilters = array(   
		"`seats`.`id`" => "ID",
		"`seats`.`name`" => "Name"
	);


	$x->QueryFieldsQS = array(   
		"`seats`.`id`" => "id",
		"`seats`.`name`" => "name"
	);


	$x->filterers = array();

	$x->QueryFrom = "`seats` ";
	$x->QueryWhere = '';
	$x->QueryOrder = '';

	$x->AllowSelection = 1;
	$x->HideTableView = ($perm[2]==0 ? 1 : 0);
	$x->AllowDelete = $perm[4];
	$x->AllowMassDelete = true;
	$x->AllowInsert = $perm[1];
	$x->AllowUpdate = $perm[3];
	$x->SeparateDV = 1;
	$x->AllowDeleteOfParents = 0;
	$x->AllowFilters = 1;
	$x->AllowSavingFilters = 0;
	$x->AllowSorting = 1;
	$x->AllowNavigation = 1;
	$x->AllowPrinting = 1;
	$x->AllowCSV = 1;
	$x->RecordsPerPage = 10;
	$x->QuickSearch = 1;
	$x->QuickSearchText = $Translation["quick search"];
	$x->ScriptFileName = "seats_view.php";
	$x->RedirectAfterInsert = "seats_view.php?SelectedID=#ID#";
	$x->TableTitle = "Seats";
	$x->TableIcon = "resources/table_icons/chair.png";
	$x->PrimaryKey = "`seats`.`id`";
	$x->DefaultSortField = '1';
	$x->DefaultSortDirection = 'desc';

	$x->ColWidth   = array(  150);
	$x->ColCaption = array("Name");
	$x->ColFieldName = array('name');
	$x->ColNumber  = array(2);


	$x->Template = 'templates/seats_templateTV.html';
	$x->SelectedTemplate = 'templates/seats_templateTVS.html';
	$x->TemplateDV = 'templates/seats_templateDV.html';
	$x->TemplateDVP = 'templates/seats_templateDVP.html';

	$x->ShowTableHeader = 1;
	$x->TVClasses = "";
	$x->DVClasses = "";
	$x->HighlightColor = '#FFF0C2';


	$DisplayRecords = $_REQUEST['DisplayRecords'];
	if(!in_array($DisplayRecords, array('user', 'group'))){ $DisplayRecords = 'all'; }
	if($perm[2]==1 || ($perm[2]>1 && $DisplayRecords=='user' && !$_REQUEST['NoFilter_x'])){ 
		$x->QueryFrom.=', membership_userrecords';
		$x->QueryWhere="where `seats`.`id`=membership_userrecords.pkValue and membership_userrecords.tableName='seats' and lcase(membership_userrecords.memberID)='".getLoggedMemberID()."'";
	}elseif($perm[2]==2 || ($perm[2]>2 && $DisplayRecords=='group' && !$_REQUEST['NoFilter_x'])){
		$x->QueryFrom.=', membership_userrecords';
		$x->QueryWhere="where `seats`.`id`=membership_userrecords.pkValue and membership_userrecords.tableName='seats' and membership_userrecords.groupID='".getLoggedGroupID()."'";
	}elseif($perm[2]==3){ 

	}elseif($perm[2]==0){ 
		$x->QueryFields = array("Not enough permissions" => "NEP");
		$x->QueryFrom = '`seats`';
		$x->QueryWhere = '';
		$x->DefaultSortField = '';
	}

	$render=TRUE;
	if(function_exists('seats_init')){
		$args=array();
		$render=seats_init($x, getMemberInfo(), $args);
	}

	if($render) $x->Render();


	$headerCode='';
	if(function_exists('seats_header')){
		$args=array();
		$headerCode=seats_header($x->ContentType, getMemberInfo(), $args);
	}  
	if(!$headerCode){
		include_once("$currDir/header.php"); 
	}else{
		ob_start(); include_once("$currDir/header.php"); $dHeader=ob_get_contents(); ob_end_clean();
		echo str_replace('<%%HEADER%%>', $dHeader, $headerCode);
	}

	echo $x->HTML;

	$footerCode='';
	if(function_exists('seats_footer')){
		$args=array();
		$footerCode=seats_footer($x->ContentType, getMemberInfo(), $args);
	}  
	if(!$footerCode){
		include_once("$currDir/footer.php"); 
	}else{
		ob_start(); include_once("$currDir/footer.php"); $dFooter=ob_get_contents(); ob_end_clean();
		echo str_replace('<%%FOOTER%%>', $dFooter, $footerCode);
	}
?>
