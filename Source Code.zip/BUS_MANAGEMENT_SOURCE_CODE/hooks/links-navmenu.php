<?php


	/* summary_reports links */
	$navLinks[] = array(
		'url' => 'hooks/summary-reports.php',
		'title' => 'Summary Reports',
		'groups' => array('Admins'),
		'icon' => 'hooks/summary_reports-logo-md.png'
	);
