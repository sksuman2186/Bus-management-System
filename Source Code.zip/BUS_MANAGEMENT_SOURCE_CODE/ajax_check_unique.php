<?php
	
	$currDir=dirname(__FILE__);
	include("$currDir/defaultLang.php");
	include("$currDir/language.php");
	include("$currDir/lib.php");

	handle_maintenance();

	header('Content-type: application/json');

	$error_return = '{ "result": "error" }';
	$ok_return = '{ "result": "ok" }';

	$table = new Request('t');
	$field = new Request('f');
	$id = new Request('id');
	$value = new Request('value');

	function cancel_all_buffers(){
		while(ob_get_level()) ob_end_clean();
		echo $GLOBALS['result'];
	}
	$GLOBALS['result'] = $error_return; 
	ob_start();
	register_shutdown_function('cancel_all_buffers');

	$table_perms = getTablePermissions($table->raw);
	if(!$table_perms[0]) exit();

	$pk = getPKFieldName($table->raw);
	if(!$pk) exit();
	$spk = makeSafe($pk, false);

	$where = "`{$field->sql}`='{$value->sql}'";
	if($id->raw){
		$where .= " and `{$spk}`!='{$id->sql}'";
	}
	$chk_query = "select count(1) from `{$table->sql}` where {$where}";
	$exists = sqlValue($chk_query);

	if($exists !== 0 && $exists !== '0') exit();

	$GLOBALS['result'] = $ok_return;
