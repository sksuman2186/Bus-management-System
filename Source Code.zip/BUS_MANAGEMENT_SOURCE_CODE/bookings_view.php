<?php

	$currDir=dirname(__FILE__);
	include("$currDir/defaultLang.php");
	include("$currDir/language.php");
	include("$currDir/lib.php");
	@include("$currDir/hooks/bookings.php");
	include("$currDir/bookings_dml.php");


	$perm=getTablePermissions('bookings');
	if(!$perm[0]){
		echo error_message($Translation['tableAccessDenied'], false);
		echo '<script>setTimeout("window.location=\'index.php?signOut=1\'", 2000);</script>';
		exit;
	}

	$x = new DataList;
	$x->TableName = "bookings";


	$x->QueryFieldsTV = array(   
		"`bookings`.`id`" => "id",
		"IF(    CHAR_LENGTH(`customers1`.`id_number`), CONCAT_WS('',   `customers1`.`id_number`), '') /* Id number */" => "id_number",
		"IF(    CHAR_LENGTH(`customers1`.`fullname`), CONCAT_WS('',   `customers1`.`fullname`), '') /* Fullname */" => "fullname",
		"IF(    CHAR_LENGTH(`customers1`.`phone`), CONCAT_WS('',   `customers1`.`phone`), '') /* Phone */" => "phone",
		"IF(    CHAR_LENGTH(`buses1`.`number`) || CHAR_LENGTH(`routes1`.`name`) || CHAR_LENGTH(`routes1`.`time`), CONCAT_WS('',   `buses1`.`number`, `routes1`.`name`, '  :', `routes1`.`time`), '') /* Bus */" => "bus",
		"IF(    CHAR_LENGTH(`seats1`.`name`), CONCAT_WS('',   `seats1`.`name`), '') /* Seat */" => "seat",
		"IF(    CHAR_LENGTH(`routes1`.`amount`), CONCAT_WS('',   `routes1`.`amount`), '') /* Amount */" => "amount",
		"IF(    CHAR_LENGTH(if(`availability1`.`date`,date_format(`availability1`.`date`,'%m/%d/%Y'),'')), CONCAT_WS('',   if(`availability1`.`date`,date_format(`availability1`.`date`,'%m/%d/%Y'),'')), '') /* Date */" => "date",
		"IF(    CHAR_LENGTH(`availability1`.`time`), CONCAT_WS('',   `availability1`.`time`), '') /* Departure Time */" => "time",
		"concat('<i class=\"glyphicon glyphicon-', if(`bookings`.`luggage`, 'check', 'unchecked'), '\"></i>')" => "luggage",
		"if(`bookings`.`date_booked`,date_format(`bookings`.`date_booked`,'%m/%d/%Y'),'')" => "date_booked"
	);

	$x->SortFields = array(   
		1 => '`bookings`.`id`',
		2 => '`customers1`.`id_number`',
		3 => '`customers1`.`fullname`',
		4 => '`customers1`.`phone`',
		5 => 5,
		6 => '`seats1`.`name`',
		7 => 7,
		8 => 'date_format(`availability1`.`date`,\'%m/%d/%Y\')',
		9 => '`availability1`.`time`',
		10 => 10,
		11 => '`bookings`.`date_booked`'
	);


	$x->QueryFieldsCSV = array(   
		"`bookings`.`id`" => "id",
		"IF(    CHAR_LENGTH(`customers1`.`id_number`), CONCAT_WS('',   `customers1`.`id_number`), '') /* Id number */" => "id_number",
		"IF(    CHAR_LENGTH(`customers1`.`fullname`), CONCAT_WS('',   `customers1`.`fullname`), '') /* Fullname */" => "fullname",
		"IF(    CHAR_LENGTH(`customers1`.`phone`), CONCAT_WS('',   `customers1`.`phone`), '') /* Phone */" => "phone",
		"IF(    CHAR_LENGTH(`buses1`.`number`) || CHAR_LENGTH(`routes1`.`name`) || CHAR_LENGTH(`routes1`.`time`), CONCAT_WS('',   `buses1`.`number`, `routes1`.`name`, '  :', `routes1`.`time`), '') /* Bus */" => "bus",
		"IF(    CHAR_LENGTH(`seats1`.`name`), CONCAT_WS('',   `seats1`.`name`), '') /* Seat */" => "seat",
		"IF(    CHAR_LENGTH(`routes1`.`amount`), CONCAT_WS('',   `routes1`.`amount`), '') /* Amount */" => "amount",
		"IF(    CHAR_LENGTH(if(`availability1`.`date`,date_format(`availability1`.`date`,'%m/%d/%Y'),'')), CONCAT_WS('',   if(`availability1`.`date`,date_format(`availability1`.`date`,'%m/%d/%Y'),'')), '') /* Date */" => "date",
		"IF(    CHAR_LENGTH(`availability1`.`time`), CONCAT_WS('',   `availability1`.`time`), '') /* Departure Time */" => "time",
		"`bookings`.`luggage`" => "luggage",
		"if(`bookings`.`date_booked`,date_format(`bookings`.`date_booked`,'%m/%d/%Y'),'')" => "date_booked"
	);

	$x->QueryFieldsFilters = array(   
		"`bookings`.`id`" => "ID",
		"IF(    CHAR_LENGTH(`customers1`.`id_number`), CONCAT_WS('',   `customers1`.`id_number`), '') /* Id number */" => "Id number",
		"IF(    CHAR_LENGTH(`customers1`.`fullname`), CONCAT_WS('',   `customers1`.`fullname`), '') /* Fullname */" => "Fullname",
		"IF(    CHAR_LENGTH(`customers1`.`phone`), CONCAT_WS('',   `customers1`.`phone`), '') /* Phone */" => "Phone",
		"IF(    CHAR_LENGTH(`buses1`.`number`) || CHAR_LENGTH(`routes1`.`name`) || CHAR_LENGTH(`routes1`.`time`), CONCAT_WS('',   `buses1`.`number`, `routes1`.`name`, '  :', `routes1`.`time`), '') /* Bus */" => "Bus",
		"IF(    CHAR_LENGTH(`seats1`.`name`), CONCAT_WS('',   `seats1`.`name`), '') /* Seat */" => "Seat",
		"IF(    CHAR_LENGTH(`routes1`.`amount`), CONCAT_WS('',   `routes1`.`amount`), '') /* Amount */" => "Amount",
		"IF(    CHAR_LENGTH(if(`availability1`.`date`,date_format(`availability1`.`date`,'%m/%d/%Y'),'')), CONCAT_WS('',   if(`availability1`.`date`,date_format(`availability1`.`date`,'%m/%d/%Y'),'')), '') /* Date */" => "Date",
		"IF(    CHAR_LENGTH(`availability1`.`time`), CONCAT_WS('',   `availability1`.`time`), '') /* Departure Time */" => "Departure Time",
		"`bookings`.`luggage`" => "Luggage",
		"`bookings`.`date_booked`" => "Date booked"
	);


	$x->QueryFieldsQS = array(   
		"`bookings`.`id`" => "id",
		"IF(    CHAR_LENGTH(`customers1`.`id_number`), CONCAT_WS('',   `customers1`.`id_number`), '') /* Id number */" => "id_number",
		"IF(    CHAR_LENGTH(`customers1`.`fullname`), CONCAT_WS('',   `customers1`.`fullname`), '') /* Fullname */" => "fullname",
		"IF(    CHAR_LENGTH(`customers1`.`phone`), CONCAT_WS('',   `customers1`.`phone`), '') /* Phone */" => "phone",
		"IF(    CHAR_LENGTH(`buses1`.`number`) || CHAR_LENGTH(`routes1`.`name`) || CHAR_LENGTH(`routes1`.`time`), CONCAT_WS('',   `buses1`.`number`, `routes1`.`name`, '  :', `routes1`.`time`), '') /* Bus */" => "bus",
		"IF(    CHAR_LENGTH(`seats1`.`name`), CONCAT_WS('',   `seats1`.`name`), '') /* Seat */" => "seat",
		"IF(    CHAR_LENGTH(`routes1`.`amount`), CONCAT_WS('',   `routes1`.`amount`), '') /* Amount */" => "amount",
		"IF(    CHAR_LENGTH(if(`availability1`.`date`,date_format(`availability1`.`date`,'%m/%d/%Y'),'')), CONCAT_WS('',   if(`availability1`.`date`,date_format(`availability1`.`date`,'%m/%d/%Y'),'')), '') /* Date */" => "date",
		"IF(    CHAR_LENGTH(`availability1`.`time`), CONCAT_WS('',   `availability1`.`time`), '') /* Departure Time */" => "time",
		"concat('<i class=\"glyphicon glyphicon-', if(`bookings`.`luggage`, 'check', 'unchecked'), '\"></i>')" => "luggage",
		"if(`bookings`.`date_booked`,date_format(`bookings`.`date_booked`,'%m/%d/%Y'),'')" => "date_booked"
	);


	$x->filterers = array(  'id_number' => 'Id number', 'bus' => 'Bus', 'seat' => 'Seat');

	$x->QueryFrom = "`bookings` LEFT JOIN `customers` as customers1 ON `customers1`.`id`=`bookings`.`id_number` LEFT JOIN `availability` as availability1 ON `availability1`.`id`=`bookings`.`bus` LEFT JOIN `buses` as buses1 ON `buses1`.`id`=`availability1`.`bus` LEFT JOIN `routes` as routes1 ON `routes1`.`id`=`availability1`.`route` LEFT JOIN `seats` as seats1 ON `seats1`.`id`=`bookings`.`seat` ";
	$x->QueryWhere = '';
	$x->QueryOrder = '';

	$x->AllowSelection = 1;
	$x->HideTableView = ($perm[2]==0 ? 1 : 0);
	$x->AllowDelete = $perm[4];
	$x->AllowMassDelete = true;
	$x->AllowInsert = $perm[1];
	$x->AllowUpdate = $perm[3];
	$x->SeparateDV = 1;
	$x->AllowDeleteOfParents = 0;
	$x->AllowFilters = 1;
	$x->AllowSavingFilters = 1;
	$x->AllowSorting = 1;
	$x->AllowNavigation = 1;
	$x->AllowPrinting = 1;
	$x->AllowCSV = 1;
	$x->RecordsPerPage = 10;
	$x->QuickSearch = 1;
	$x->QuickSearchText = $Translation["quick search"];
	$x->ScriptFileName = "bookings_view.php";
	$x->RedirectAfterInsert = "bookings_view.php?SelectedID=#ID#";
	$x->TableTitle = "Bookings";
	$x->TableIcon = "resources/table_icons/accordion.png";
	$x->PrimaryKey = "`bookings`.`id`";
	$x->DefaultSortField = '1';
	$x->DefaultSortDirection = 'desc';

	$x->ColWidth   = array(  150, 150, 150, 150, 150, 150, 150, 150, 150, 150);
	$x->ColCaption = array("Id number", "Fullname", "Phone", "Bus", "Seat", "Amount", "Date", "Departure Time", "Luggage", "Date booked");
	$x->ColFieldName = array('id_number', 'fullname', 'phone', 'bus', 'seat', 'amount', 'date', 'time', 'luggage', 'date_booked');
	$x->ColNumber  = array(2, 3, 4, 5, 6, 7, 8, 9, 10, 11);


	$x->Template = 'templates/bookings_templateTV.html';
	$x->SelectedTemplate = 'templates/bookings_templateTVS.html';
	$x->TemplateDV = 'templates/bookings_templateDV.html';
	$x->TemplateDVP = 'templates/bookings_templateDVP.html';

	$x->ShowTableHeader = 1;
	$x->TVClasses = "";
	$x->DVClasses = "";
	$x->HighlightColor = '#FFF0C2';


	$DisplayRecords = $_REQUEST['DisplayRecords'];
	if(!in_array($DisplayRecords, array('user', 'group'))){ $DisplayRecords = 'all'; }
	if($perm[2]==1 || ($perm[2]>1 && $DisplayRecords=='user' && !$_REQUEST['NoFilter_x'])){
		$x->QueryFrom.=', membership_userrecords';
		$x->QueryWhere="where `bookings`.`id`=membership_userrecords.pkValue and membership_userrecords.tableName='bookings' and lcase(membership_userrecords.memberID)='".getLoggedMemberID()."'";
	}elseif($perm[2]==2 || ($perm[2]>2 && $DisplayRecords=='group' && !$_REQUEST['NoFilter_x'])){
		$x->QueryFrom.=', membership_userrecords';
		$x->QueryWhere="where `bookings`.`id`=membership_userrecords.pkValue and membership_userrecords.tableName='bookings' and membership_userrecords.groupID='".getLoggedGroupID()."'";
	}elseif($perm[2]==3){
	}elseif($perm[2]==0){ 
		$x->QueryFields = array("Not enough permissions" => "NEP");
		$x->QueryFrom = '`bookings`';
		$x->QueryWhere = '';
		$x->DefaultSortField = '';
	}

	$render=TRUE;
	if(function_exists('bookings_init')){
		$args=array();
		$render=bookings_init($x, getMemberInfo(), $args);
	}

	if($render) $x->Render();


	$headerCode='';
	if(function_exists('bookings_header')){
		$args=array();
		$headerCode=bookings_header($x->ContentType, getMemberInfo(), $args);
	}  
	if(!$headerCode){
		include_once("$currDir/header.php"); 
	}else{
		ob_start(); include_once("$currDir/header.php"); $dHeader=ob_get_contents(); ob_end_clean();
		echo str_replace('<%%HEADER%%>', $dHeader, $headerCode);
	}

	echo $x->HTML;

	$footerCode='';
	if(function_exists('bookings_footer')){
		$args=array();
		$footerCode=bookings_footer($x->ContentType, getMemberInfo(), $args);
	}  
	if(!$footerCode){
		include_once("$currDir/footer.php"); 
	}else{
		ob_start(); include_once("$currDir/footer.php"); $dFooter=ob_get_contents(); ob_end_clean();
		echo str_replace('<%%FOOTER%%>', $dFooter, $footerCode);
	}
?>
